/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/* 
Various checksum routines taken from TCPDUMP and http://www.bytebot.net/rrjcode/ratelimit-0.1/
*/

#include "checksum.h"


int SumWords(u_int16_t *buf, int nwords) {
    register u_int32_t    sum = 0;

    while (nwords >= 16) {
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        sum += (u_int16_t) ntohs(*buf++);
        nwords -= 16;
    }
    while (nwords--)
        sum += (u_int16_t) ntohs(*buf++);
    return(sum);
}

void IpChecksum(struct ip *ip) {
    register u_int32_t    sum;

    ip->ip_sum = 0;
    sum = SumWords((u_int16_t *) ip, ip->ip_hl << 1);

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    sum = ~sum;

    ip->ip_sum = htons(sum);
}


void UdpChecksum(struct ip *ip) {
    struct udphdr *const udp = (struct udphdr *) ((long *) ip + ip->ip_hl);
    u_int32_t     sum;

    udp->uh_sum = 0;

    sum = SumWords((u_int16_t *) &ip->ip_src, 4);
    sum += (u_int16_t) IPPROTO_UDP;
    sum += (u_int16_t) ntohs(udp->uh_ulen);

    sum += SumWords((u_int16_t *) udp, ((u_int16_t) ntohs(udp->uh_ulen)) >> 1);
    if (ntohs(udp->uh_ulen) & 1)
        sum += (u_int16_t) (((u_char *) udp)[ntohs(udp->uh_ulen) - 1] << 8);

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    sum = ~sum;

    udp->uh_sum = htons(sum);
}
