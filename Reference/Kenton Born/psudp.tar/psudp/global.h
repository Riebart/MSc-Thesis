/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef global_h
#define global_h


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <netinet/ether.h>
#include <netdb.h>
#define __FAVOR_BSD
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <getopt.h>
#include <stdarg.h>
#include <syslog.h>
#include <pthread.h>
#include <openssl/lhash.h>
#include <linux/types.h>

#include "list.h"

#define DNS_RR_START 12  /* Distance from start of DNS header to RR */
#define RR_RESPONSE_INFO_LENGTH 10 /* from name to start of rr rdata */
#define RR_QUERY_INFO_LENGTH 4 /* from name to start of next rr */
#define DNS_LENGTH 512

#define UDP_HDR_LENGTH 8 /* length of a UDP header */

#define MAX_MESSAGE_LEN 255

/* The four types of DNS RR */
enum {
    QUERY,
    ANSWER,
    AUTHORITATIVE,
    ADDITIONAL,
};

/* IP HEADER */
typedef struct {
    u_int8_t        ip_vhl;             /* header length, version */
#define IP_V(ip)        (((ip)->ip_vhl & 0xf0) >> 4)
#define IP_HL(ip)       ((ip)->ip_vhl & 0x0f)
    u_int8_t        ip_tos;             /* type of service */
    u_int16_t       ip_len;             /* total length */
    u_int16_t       ip_id;              /* identification */
    u_int16_t       ip_off;             /* fragment offset field */
#define IP_DF 0x4000                    /* dont fragment flag */
#define IP_MF 0x2000                    /* more fragments flag */
#define IP_OFFMASK 0x1fff               /* mask for fragmenting bits */
    u_int8_t        ip_ttl;             /* time to live */
    u_int8_t        ip_p;               /* protocol */
    u_int16_t       ip_sum;             /* checksum */
    struct in_addr  ip_src,ip_dst;      /* source and dest address */
} IP_HEADER;

/* UDP HEADER */
typedef struct {
    unsigned short src_port; //source port
    unsigned short dst_port; //dest port
    unsigned short length; //length
    unsigned short checksum; //checksum
} UDP_HEADER;


/** DNS_HEADER from www.binarytides.com/blog/dns-query-code-in-c-with-windosck-and-linux-sockets **/

/* DNS HEADER */
typedef struct {
    unsigned short id;       // identification number
    unsigned char rd :1;     // recursion desired
    unsigned char tc :1;     // truncated message
    unsigned char aa :1;     // authoritive answer
    unsigned char opcode :4; // purpose of message
    unsigned char qr :1;     // query/response flag
    unsigned char rcode :4;  // response code
    unsigned char cd :1;     // checking disabled
    unsigned char ad :1;     // authenticated data
    unsigned char z :1;      // its z! reserved
    unsigned char ra :1;     // recursion available
    unsigned short q_count;  // number of question entries
    unsigned short ans_count; // number of answer entries
    unsigned short auth_count; // number of authority entries
    unsigned short add_count; // number of resource entries
} DNS_HEADER;

/* holds info about a request/response domain */
typedef struct {
    char fqdn[256];
    char* domain; //should simply point to the location in the fqdn
    char* tld; //should simply point ot the location in the fqdn
} DOMAIN_INFO;

/* Resource Records */

typedef struct {
    uint16_t     type; //type
    uint16_t     cls; //class
    uint32_t     ttl; //time to live
    uint16_t     rd_length; // rd length;
    char*        rdata; //rdata
} __attribute__ ((__packed__)) RR_INFO; //resource record


/*Domain Label Header for DNS RR Parsing */
typedef struct {
    unsigned char  value :6;
    unsigned char  type :2;
#define LABEL_EDNS0      1
#define LABEL_UNDEFINED  2
#define LABEL_PTR        3
} __attribute__ ((__packed__)) LABEL_HEADER;

int get_host(char *const name, struct addrinfo *res);

#endif
