/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef hashmap_h
#define hashmap_h

#include <openssl/lhash.h>

typedef struct  {
    LHASH   *tab;
    time_t  lim;
    void    *content;
    int     cont_len;
}   ALL_ARG;

typedef struct _tn {
    char        *key;
    void        *content;
    time_t      last_acc;
}   TABNODE;


unsigned long
t_hash(const TABNODE *e); /* hashing function */

int
t_cmp(const TABNODE *d1, const TABNODE *d2); /* comparison function */

void* 
t_find(LHASH *const tab, char *const key); /* Find a key */

void
t_add(LHASH *const tab, const char *key, const void *content, const size_t cont_len); /* Add a tab/key pair */

void 
t_remove(LHASH *const tab, char *const key); /* Delete a key */

void 
t_expire(LHASH *const tab, const time_t lim); /* Expire all old nodes */

void 
t_clean(LHASH *const tab, void *const content, const size_t cont_len); /* remove all nodes with given content */

LHASH* create_hashmap(void);

#endif
