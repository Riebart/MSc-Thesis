/*
LISTENER - A program that interprets injected dns traffic to re-build files on a           remote system.

Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "listener.h"

/** Pcap initialization derived from from http://yuba.stanford.edu/~casado/pcap **/


unsigned short dns_port = 53; /* default port for DNS */
char *domain = NULL;
char *file_name;
short on_queries = 1;


static void
usage(void)
{
    fprintf(stdout, "\n\nTunnel Listener usage: listener [options]\nOptions:\n");
    fprintf(stdout, "\t-r - listen to responses (default: queries)\n");
    fprintf(stdout, "\t-d <domain>- domain to listen to (required)\n");
    fprintf(stdout, "\t-f <file> - file to save to\n");
    fprintf(stdout, "\t-p <file> - pcap file (default: listen live)\n");
    fprintf(stdout, "\t-h - display usage\n");
    fprintf(stdout, "\n");
    exit(-1);
}



/****************************************************************************
* handle_dns inspects the DNS packets, parsing the tunneled data when present
* **************************************************************************/
void handle_dns(IP_HEADER *ip_hdr) {
    DOMAIN_INFO domain_info;
    memset(&domain_info, 0, sizeof(DOMAIN_INFO));

    int hdr_length = IP_HL(ip_hdr)*4; //IP_HL returns # of 32 bit words
    
    UDP_HEADER *udp_hdr = (UDP_HEADER *)((char*)ip_hdr + hdr_length);
    DNS_HEADER *dns_hdr = (DNS_HEADER *)((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);
   
    /* Get the start of the dns data and the start of the resource records */
    char* dns_start = ((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);
    char* curr_ptr = dns_start + DNS_RR_START;

    if(dns_hdr->qr == 0 && on_queries == 1) { /* a query of interest */
        curr_ptr = handle_query_record(dns_start, curr_ptr, &domain_info);
        if(strncmp(domain_info.domain, domain, strlen(domain)))
            return;
    }
    else if(dns_hdr->qr == 1 && on_queries == 0) { /* a response of interest */
        curr_ptr = handle_query_record(dns_start, curr_ptr, &domain_info);
        if(strncmp(domain_info.domain, domain, strlen(domain)))
            return;

        /* now find the actual end of the resource records */
        /* NOTE: not currently using domain_info for anything here */
        int i;
        for(i = 0; i < ntohs(dns_hdr->ans_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, ANSWER);
        }

        for(i = 0; i < ntohs(dns_hdr->auth_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, AUTHORITATIVE);
        }

        for(i = 0; i < ntohs(dns_hdr->add_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, ADDITIONAL);
        }
    }
    else
        return;

    /* compare the declared length to the actual length */
    int udp_len = ntohs(udp_hdr->length);
    int cur_len = (uint32_t)curr_ptr - (uint32_t)dns_start + 8;

    if(udp_len > cur_len) { /* there is extra data at the end */
        int diff = udp_len - cur_len;

        /* grab the extra data at the end of the packet */
        char infil[diff+1];
        memset(infil, 0, diff+1);
        memcpy(infil, curr_ptr, diff);

        /* If a file was specified, append the data to it. Otherwise, stdout */
        if(file_name) {
            FILE *file_ptr = fopen(file_name, "a+"); //append to file
            fprintf(file_ptr, "%s", infil);
            fclose(file_ptr);
        }
        else
            printf("%s",infil);
    }
}


/****************************************************************************
* handle_ip verified that we have the correct type of packet and passes it to
* handle_DNS
* **************************************************************************/
void handle_ip(u_char *args,const struct pcap_pkthdr* pkthdr,const u_char* packet) {
    IP_HEADER *ip_hdr;
    u_int length = pkthdr->len;
    u_int hlen,off,version;
    int len;

    /* jump pass the ethernet header */
    ip_hdr = (IP_HEADER*)(packet + sizeof(struct ether_header));
    length -= sizeof(struct ether_header);

    /* check to see we have a packet of valid length */
    if (length < sizeof(IP_HEADER)) {
        fprintf(stderr,"truncated ip %d\n",length);
        return;
    }

    len     = ntohs(ip_hdr->ip_len);
    hlen    = IP_HL(ip_hdr); /* header length */
    version = IP_V(ip_hdr);/* ip version */

    /* check version */
    if(version != 4) {
      fprintf(stderr, "Unknown version %d\n", version);
      return;
    }

    /* check header length */
    if(hlen < 5 ) {
        fprintf(stderr,"bad-hlen %d\n",hlen);
    }

    /* see if we have as much packet as we should */
    if(length < len)
        fprintf(stderr,"truncated IP - %d bytes missing\n",len - length);

    /* Check to see if we have the first fragment */
    off = ntohs(ip_hdr->ip_off);

    if(ip_hdr->ip_p == 17) // protocol == DNS
        handle_dns(ip_hdr); //TODO: might be TCP!

    return;
}

/****************************************************************************
* packet_handler verifies we have an IP packet and passes it to handle_ip
* **************************************************************************/
void packet_handler(u_char *args,const struct pcap_pkthdr* pkthdr,const u_char* packet) {
    struct ether_header *e_ptr = (struct ether_header *) packet; /* net/ethernet.h */

    if(ntohs (e_ptr->ether_type) == ETHERTYPE_IP) { /* IP */
        handle_ip(args, pkthdr, packet);
    }
}


/****************************************************************************
* main function - enough said
* **************************************************************************/
int main(int argc,char **argv)
{
    char *pcap_file = NULL;
    char *filter = NULL;

    /* pcap fun */
    char *dev; 
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t* descr;
    struct bpf_program fp;      /* hold compiled program     */
    bpf_u_int32 maskp;          /* subnet mask               */
    bpf_u_int32 netp;           /* ip                        */
    u_char* pcap_args = NULL;


    int c_opt;
    while((c_opt = getopt(argc, argv, "d:f:p:rh")) > 0)
        switch(c_opt) {
        case 'f':
            file_name = optarg;
            break;
        case 'd':
            domain = optarg;
            break;
        case 'r':
            on_queries = 0;
            break;
        case 'p':
            pcap_file = optarg;
        default:
            usage();
        }

    if(domain == NULL) {
        printf("A domain must be specified\n\n");
        usage();
    }

    if(filter == NULL)
        filter = strdup("(dst port 53 or src port 53) and ip proto \\udp");


    if(pcap_file) {
        descr = pcap_open_offline(pcap_file, errbuf);
        if(descr == NULL) {
            fprintf(stderr,"Error opening pcap file: %s\n", errbuf);
            exit(-1);
        }

        printf("Opened pcap file: %s\n", pcap_file);
    }
    else {
        /* grab a device to peak into... */
        dev = pcap_lookupdev(errbuf);
        if(dev == NULL) { 
            fprintf(stderr,"%s\n",errbuf);
            exit(-1); 
        }

        /* ask pcap for the network address and mask of the device */
        pcap_lookupnet(dev,&netp,&maskp,errbuf);

        /* open device for reading. NOTE: defaulting to promiscuous mode */
        descr = pcap_open_live(dev,BUFSIZ,1,-1,errbuf);
        if(descr == NULL) { 
            fprintf(stderr,"pcap_open_live(): %s\n",errbuf); 
            exit(1); 
        }
    }

    /* Lets try and compile the program.. non-optimized */
    if(pcap_compile(descr,&fp, filter,0,netp) == -1) {
        fprintf(stderr,"Error calling pcap_compile\n"); 
        exit(1); 
    }

    /* set the compiled program as the filter */
    if(pcap_setfilter(descr,&fp) == -1) { 
        fprintf(stderr,"Error setting filter\n"); 
        exit(1); 
    }

    printf("ready!\n\n");
    /* ... and loop */ 
    pcap_loop(descr, -1, packet_handler, pcap_args);

    return 0;
}

