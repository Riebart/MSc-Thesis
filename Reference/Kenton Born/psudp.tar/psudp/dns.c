/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "dns.h"


/****************************************************************************
* parse_labels  parses the labels of one record  and returns the position in 
* the packet after the labels. 
* **************************************************************************/
char* parse_labels(char* start_loc, char* curr_ptr, LLIST *label_list) {
    LABEL_HEADER *l_hdr;
    char *ret_ptr = curr_ptr;
    int ptr_found = 0;

    /* we need to keep track of visited adrs to prevent recursive DDOS */
    uint32_t visited_addrs[256];
    memset(visited_addrs, 0, 256*sizeof(uint32_t));

    while(1) {
        l_hdr = (LABEL_HEADER *)curr_ptr;
        curr_ptr++;
        
        if(!ptr_found)
            ret_ptr++;
        
        if(l_hdr->type == LABEL_UNDEFINED) {
            fprintf(stderr, "UNDEFINED record label found\n");
            return ret_ptr;
        }
        else if(l_hdr->type == LABEL_EDNS0) { //RFC 2671
            fprintf(stderr, "I am too lazy to mess with EDNS0\n");
            return ret_ptr;
        }
        else if(l_hdr->type == LABEL_PTR) {
            if(!ptr_found) {
                ret_ptr++;
                ptr_found = 1;
            }
            curr_ptr = start_loc + (l_hdr->value << 8) + (uint8_t)*curr_ptr;
            
            int i;
            for(i = 0; visited_addrs[i] != 0; i++) {
                if(visited_addrs[i] == (uint32_t)curr_ptr) {
                    fprintf(stderr, "Recursive Ptr found!");
                    return ret_ptr;
                }
            }
            visited_addrs[i] = (uint32_t)curr_ptr;
        }
        else if(l_hdr->value != 0) {
            list_insert_end(label_list, strndup(curr_ptr, l_hdr->value));
            curr_ptr += l_hdr->value;
            if(!ptr_found)
                ret_ptr += l_hdr->value;
        }
        else {
            return ret_ptr;
        }
    }
}


/****************************************************************************
* get_domain_info analyzes a linked list of labels for the tld, domain, and 
* subdomains, storing them in the DOMAIN_INFO object
* **************************************************************************/
void get_domain_info(LLIST *label_list, DOMAIN_INFO *domain_info) {
    char *fqdn = domain_info->fqdn;
    domain_info->domain = fqdn;
    domain_info->tld = fqdn;
    memset(fqdn, 0, 256);

    int num_labels = label_list->num_elements;
    NODE *curr_node = label_list->first;
    while(curr_node) {
        strncat(fqdn, curr_node->data, 253-strlen(fqdn));
        num_labels--;  
        if(num_labels > 0)
            strcat(fqdn,".");

        if(num_labels == 2) {
            domain_info->domain = fqdn + strlen(fqdn);
        }
        else if(num_labels == 1) {
            domain_info->tld = fqdn + strlen(fqdn);
        }
        curr_node = curr_node->next;
    }
}

/****************************************************************************
* handle_request_record parses 1 record and returns the position in the 
* packet after the record. 
* **************************************************************************/ 
char* handle_query_record(char *dns_start, char *curr_ptr, DOMAIN_INFO *domain_info) {
    LLIST label_list;
    memset(&label_list, 0, sizeof(label_list));

    curr_ptr = parse_labels(dns_start, curr_ptr, &label_list);
    get_domain_info(&label_list, domain_info);

    curr_ptr += RR_QUERY_INFO_LENGTH;
    list_clear(&label_list);

    return curr_ptr;
}

/****************************************************************************
* handle_response_record parses 1 record and returns the position in the 
* packet after the record.
* NOTE: rr_type currently unused 
* **************************************************************************/
char* handle_response_record(char *dns_start, char *curr_ptr, DOMAIN_INFO *domain_info, int rr_type) {
    LLIST label_list;
    memset(&label_list, 0, sizeof(label_list));
  
    curr_ptr = parse_labels(dns_start, curr_ptr, &label_list);
    get_domain_info(&label_list, domain_info);

    RR_INFO *rr_info = (RR_INFO*) curr_ptr;

    curr_ptr += RR_RESPONSE_INFO_LENGTH + ntohs(rr_info->rd_length);
    list_clear(&label_list);

    return curr_ptr;
}
