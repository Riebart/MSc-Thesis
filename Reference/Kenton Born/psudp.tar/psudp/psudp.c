/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "client.h"



static void
usage(void)
{
    fprintf(stdout, "\n\nPSUDP messenger usage: psudp [options]\nOptions:\n");
    fprintf(stdout, "\t-d <ip> - ip the broker should send the message to\n");
    fprintf(stdout, "\t-m <msg> - message to send\n");
    fprintf(stdout, "\t-s <sock> - unix domain socket of the client (default: /tmp/psudp)");
    fprintf(stdout, "\t-h - display usage\n");
    fprintf(stdout, "\n");
    exit(-1);
}

static int
get_sock(const char *sock_name)
{
    struct sockaddr_un  ctrl;
    int                 res;

    memset(&ctrl, 0, sizeof(ctrl));
    ctrl.sun_family = AF_UNIX;
    strncpy(ctrl.sun_path, sock_name, sizeof(ctrl.sun_path) - 1);
    if((res = socket(PF_UNIX, SOCK_STREAM, 0)) < 0) {
        perror("socket create");
        exit(1);
    }
    if(connect(res, (struct sockaddr *)&ctrl, (socklen_t)sizeof(ctrl)) < 0) {
        perror("connect");
        exit(1);
    }
    return res;
}

int main(const int argc, char **argv) {
    MSG msg;
    int sock;
    char *arg0, *sock_name;
    int c_opt;

    arg0 = *argv;
    sock_name = NULL;

    memset(&msg, 0, sizeof(msg));
    opterr = 0;

    while((c_opt = getopt(argc, argv, "d:m:s:")) > 0)
        switch(c_opt) {
        case 'd':
            strncpy(msg.ip, optarg, INET_ADDRSTRLEN);
            break;
        case 'm':
            strncpy(msg.msg, optarg, MAX_MESSAGE_LEN);
            break;
        case 's':
            sock_name = optarg;
            break;
        default:
            usage();
        }

    /* first, do some input validation */

    if(sock_name == NULL)
        sock_name = strdup("/tmp/psudp");

    if(strlen(msg.ip) <= 0) {
        printf("specify a destination ip - aborting!\n");
        exit(-1);
    }
    else {
        struct addrinfo dummy;
        memset(&dummy, 0, sizeof(dummy));
        if(get_host(msg.ip, &dummy)) {
            printf("Invalid ip (%s) - aborting!\n", msg.ip);
            exit(-1);
        }
    }

    if(strlen(msg.msg) > 200) {
        printf("You would fail at being a ninja - aborting!\n");
        usage();
    }

    if(strlen(msg.msg) <= 0) {
        printf("I don't know what to send!\n");
        usage();
    }

    /* now send the data! */
    printf("sending %s to %s\n", msg.msg, msg.ip);
    sock = get_sock(sock_name);
    write(sock, &msg, sizeof(msg));
   
    return 0;
}
    

