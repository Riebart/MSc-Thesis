/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

//This file is derived from en.literateprograms.org/Singly_linked_list(c)

#ifndef list_h
#define list_h

#include <stdlib.h>
#include <string.h>
#include <stdio.h>


typedef struct _node {
    char *data;
    struct _node *next;
} NODE;

typedef struct  {
    struct _node *first;
    unsigned int num_elements;
} LLIST;


void list_insert_after(LLIST *list, NODE *node, char *data); /* insert node in middle of list */

void list_insert_end(LLIST *list, char *data); /* insert node at end of list */

void list_insert_beginning(LLIST *list, char *data); /* insert node at beginning of list */

int list_remove(LLIST *list, NODE *node); /* removes a node, returns 1 on success */

void list_clear(LLIST *list); /* clear all the elements in a list */

NODE *list_contains(LLIST *list, char *data); /* returns address of node containing the data (0, otherwise) */

int list_remove_first(LLIST *list); /* removes first element from the list */

int list_is_empty(LLIST *list); /* returns 1 if empty, 0 otherwise */
#endif
