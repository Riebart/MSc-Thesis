/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "client.h"

//#define DEBUG

char *file_name;

char *sock_name; 
int msg_sock;

LLIST msg_list;
LLIST ip_list;

static void
usage(void)
{
    fprintf(stdout, "\n\nPSUDP Client usage: client [options]\nOptions:\n");
    fprintf(stdout, "\t-s <unix_socket> - socket to listen on for messages (default: /tmp/psudp)\n");
    fprintf(stdout, "\t-f <file> - file to save messages to (default: print to screen)\n");
    fprintf(stdout, "\t-h - display usage\n");
    fprintf(stdout, "\n");
    exit(-1);
}

/****************************************************************************
* handle_dns determines whether or not to inject data into the dns packet
* based on the domain, direction of the packet, etc. The function returns 
* the amount of data injected into the packet
* **************************************************************************/
long handle_dns(IP_HEADER *ip_hdr) {
    int hdr_length = IP_HL(ip_hdr)*4; //IP_HL returns # of 32 bit words
    
    UDP_HEADER *udp_hdr = (UDP_HEADER *)((char*)ip_hdr + hdr_length);
    DNS_HEADER *dns_hdr = (DNS_HEADER *)((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);

    short ip_len = ntohs(ip_hdr->ip_len);
    short udp_len = ntohs(udp_hdr->length);

    char* dns_start = ((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);
    char *dns_end = ((char *)udp_hdr) + udp_len;

    char* curr_ptr = dns_start + DNS_RR_START;

    if(ntohs(udp_hdr->src_port) == 53) {
#ifdef DEBUG
        printf("received response\n");
#endif

        DOMAIN_INFO domain_info;
        memset(&domain_info, 0, sizeof(domain_info));

        curr_ptr = handle_query_record(dns_start, curr_ptr, &domain_info);
        
        /* now find the actual end of the resource records */
        /* NOTE: not currently using domain_info for anything here */
        int i;
        for(i = 0; i < ntohs(dns_hdr->ans_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, ANSWER);
        }
        for(i = 0; i < ntohs(dns_hdr->auth_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, AUTHORITATIVE);
        }
        for(i = 0; i < ntohs(dns_hdr->add_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, ADDITIONAL);
        }

        /* compare the declared length to the actual length */
        int udp_len = ntohs(udp_hdr->length);
        int cur_len = (uint32_t)curr_ptr - (uint32_t)dns_start + 8;

        if(udp_len > cur_len) { /* there is extra data at the end */
            int diff = udp_len - cur_len;

            /* grab the extra data at the end of the packet */
            char infil[diff+1];
            memset(infil, 0, diff+1);
            memcpy(infil, curr_ptr, diff);

            /* If a file was specified, append the data to it. Otherwise, stdout */
            if(file_name) {
                FILE *file_ptr = fopen(file_name, "a+"); //append to file
                fprintf(file_ptr, "%s", infil);
                fclose(file_ptr);
            }
            else
                printf("%s\n",infil);

            ip_hdr->ip_len = htons(ip_len - diff);
            udp_hdr->length = htons(udp_len - diff);
            return -diff;
        }
        return 0;
    }
    else if(ntohs(udp_hdr->dst_port) == 53) {

#ifdef DEBUG
        printf("sending query\n");
#endif

        if(list_is_empty(&msg_list)) {

#ifdef DEBUG
            printf("No message to send!\n");
#endif

            return 0;
        }
        else {
            char buf[INET_ADDRSTRLEN + MAX_MESSAGE_LEN + 3];
            memset(buf, 0, INET_ADDRSTRLEN + MAX_MESSAGE_LEN + 3);

            strncpy(buf, ip_list.first->data, INET_ADDRSTRLEN);
            strcat(buf, "@"); //delimiter used for parsing at broker
            strncat(buf, msg_list.first->data, MAX_MESSAGE_LEN);

            int buf_len = strlen(buf);
            if(buf_len > (512 - udp_len)) //packet is too large, skip it
                return 0;
            
            memcpy(dns_end, buf, buf_len);
	    
            ip_hdr->ip_len = htons(ip_len + buf_len);
            udp_hdr->length = htons(udp_len + buf_len);

            IpChecksum((struct ip *)ip_hdr);
            UdpChecksum((struct ip *)ip_hdr);

#ifdef DEBUG
            printf("sending %s to %s\n", msg_list.first->data, ip_list.first->data);
#endif

            list_remove_first(&msg_list);
            list_remove_first(&ip_list);

            return buf_len;
        }
    }
    else {
        printf("Error: configure iptables correctly!\n");
        return 0;
    }
}

/****************************************************************************
* cb is the callback function passed to netfilter_queue, and is called after
* every packet that is received
* **************************************************************************/
static int cb(struct nfq_q_handle *qh, struct nfgenmsg *nfmsg, struct nfq_data *nfa, void *data) {
    int ret;
    char *pkt_data;
    char new_pkt[5000];
    int id = 0;
    struct nfqnl_msg_packet_hdr *ph;

    memset(new_pkt, 0, 5000);

    ph = nfq_get_msg_packet_hdr(nfa);
    if(ph) {
        id = ntohl(ph->packet_id);
    }

    ret = nfq_get_payload(nfa, &pkt_data);
    memcpy(new_pkt, pkt_data, ret);

    ///////HANDLE IP PACKET///////
    IP_HEADER *ip_hdr = (IP_HEADER *)new_pkt;

    u_int hlen,version;
    int len;

    len     = ntohs(ip_hdr->ip_len);
    hlen    = IP_HL(ip_hdr); /* header length */
    version = IP_V(ip_hdr);/* ip version */

    /* check version */
    if(version != 4) {
      fprintf(stderr,"Unknown version %d\n",version);
    }

    /* check header length */
    if(hlen < 5 ) {
        fprintf(stderr,"bad-hlen %d\n",hlen);
    }

    //TODO: CHECK FOR FRAGMENTS/TRUNCATED
    long mod_len = handle_dns(ip_hdr);

    return nfq_set_verdict(qh, id, NF_ACCEPT, ret + mod_len, (unsigned char*)new_pkt);
}


void * thr_msg(void *arg) {
    MSG msg;
    struct sockaddr sa;
    struct addrinfo addr;
    int sock, dummy;
    struct pollfd polls;

    dummy = sizeof(sa);
    memset(&msg, 0, sizeof(msg));

    for(;;) {
        polls.fd = msg_sock;
        polls.events = POLLIN | POLLPRI;
        polls.revents = 0;
        
        if(poll(&polls, 1, -1) < 0) {
            printf("Error calling poll - %s\n", strerror(errno));
            continue;
        }

        if((sock = accept(msg_sock, &sa, (socklen_t *)&dummy)) < 0) {
            printf("Error accepting on msg socket - %s\n", strerror(errno));
            continue;
        }

        if(read(sock, &msg, sizeof(msg)) != sizeof(msg)) {
            printf("Error reading socket msg: %s\n", strerror(errno));
            continue;
        }

        memset(&addr, 0, sizeof(addr));

        if(msg.ip == NULL) {
            printf("message IP cannot be null\n");
            continue;
        }   
        else if(get_host(msg.ip, &addr)) {
            printf("Invalid IP: %s\n", msg.ip);
            continue;
        }

        if(msg.msg != NULL) {

#ifdef DEBUG
            printf("inserting msg %s for %s\n", msg.msg, msg.ip);
#endif

            list_insert_end(&msg_list, strdup(msg.msg));
            list_insert_end(&ip_list, strdup(msg.ip));
        }
        else
            printf("msg is NULL!\n");
    }
        
    return NULL;
}

/****************************************************************************
* main function - enough said
* **************************************************************************/
int main(int argc, char **argv) {
    struct nfq_handle *h;
    struct nfq_q_handle *qh;
    int fd;
    int rv;
    char buf[4096] __attribute__ ((aligned));

    file_name = NULL;
    sock_name = NULL;

    int c_opt;
    while((c_opt = getopt(argc, argv, "s:f:")) > 0)
        switch(c_opt) {
        case 's':
            sock_name = optarg;
            break;
        case 'f':
            file_name = optarg;
        default:
            usage();
        }

    if(sock_name == NULL)
        sock_name = strdup("/tmp/psudp");
    
    memset(&msg_list, 0, sizeof(msg_list));
    memset(&ip_list, 0, sizeof(ip_list));

    if(sock_name != NULL) {
        struct sockaddr_un msg_sockaddr;
        pthread_t thr;
        pthread_attr_t attr;

        /* initialize sockaddr_un */
        memset(&msg_sockaddr, 0, sizeof(msg_sockaddr));
        msg_sockaddr.sun_family = AF_UNIX;
        strncpy(msg_sockaddr.sun_path, sock_name, sizeof(msg_sockaddr.sun_path) -1);
        (void)unlink(msg_sockaddr.sun_path);

        /* create socket */
        if((msg_sock = socket(PF_UNIX, SOCK_STREAM, 0)) < 0) {
            printf("Could not create listening socket - aborting!\n");
            exit(-1);
        }

        /* bind socket */
        if(bind(msg_sock, (struct sockaddr *)&msg_sockaddr, (socklen_t)sizeof(msg_sockaddr)) < 0) {
            printf("Could not bind socket (%s) - aborting!\n", strerror(errno));
            exit(-1);
        }
        listen(msg_sock, 512);

        //create a new thread for listening to the control socket
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

#ifdef  NEED_STACK
        /* set new stack size - necessary for OPENBSD/FreeBSD and Linux NPTL */
        if(pthread_attr_setstacksize(&attr, 1 << 18)) {
            printf("Can't set stack size - aborting!\n");
            exit(-1);
        }
#endif
        /* start listening for messages on the socket */
        if(pthread_create(&thr, &attr, thr_msg, NULL)) {
            printf("Could not create msg thread - aborting!\n");
            exit(-1);
        }
        
        printf("listening for messages to send on socket: %s\n", sock_name);
    }
    else {
        printf("not listening for messages to send\n");
        msg_sock = -1;
    }


    /*Now set up nf_queue nonsense*/
#ifdef DEBUG
    printf("opening library handle\n");
#endif

    h = nfq_open();
    if(!h) {
        fprintf(stderr, "error during nfq_open()\n");
        exit(1);
    }

#ifdef DEBUG
    printf("unbinding existing nf_queue_handler for AF_INET (if any)\n");
#endif

    if(nfq_unbind_pf(h, AF_INET) < 0) {
        fprintf(stderr, "error during nfq_unbind_pf()\n(permissions?)\n");
        exit(1);
    }

#ifdef DEBUG
    printf("binding nfnetlink_queue as nf_queue handler for AF_INET\n");
#endif

    if(nfq_bind_pf(h, AF_INET) < 0) {
        fprintf(stderr, "error during nfq_bind_pf()\n");
        exit(1);
    }

#ifdef DEBUG
    printf("binding this socket to queue '0'\n");
#endif

    qh = nfq_create_queue(h, 0, &cb, NULL);
    if(!qh) {
        fprintf(stderr, "error during nfq_create_queue()\n");
        exit(1);
    }

#ifdef DEBUG
    printf("setting copy packet mode\n");
#endif

    if(nfq_set_mode(qh, NFQNL_COPY_PACKET, 0xffff) < 0) {
        fprintf(stderr, "can't set packet_copy mode\n");
        exit(1);
    }

    fd = nfq_fd(h);

    printf("ready!\n\n");

    while((rv = recv(fd, buf, sizeof(buf), 0)) && rv >= 0) {
        nfq_handle_packet(h, buf, rv);
    }

#ifdef DEBUG
    printf("unbinding from queue 0\n");
#endif

    nfq_destroy_queue(qh);

#ifdef INSANE
    /* normally, applications SHOULD NOT issue this command, since it 
     * detaches other programs/sockets from AF_INET, too! */
    nfq_unbind_pf(h, AF_INET);
#endif

#ifdef DEBUG
    printf("closing library handle\n");
#endif

    nfq_close(h);

    exit(0);
}

