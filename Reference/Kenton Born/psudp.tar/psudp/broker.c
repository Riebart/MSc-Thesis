/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "broker.h"

//#define DEBUG

LLIST reg_list;
LHASH             *msg_hash;     /* hashmap for lists by ip */
pthread_mutex_t   msg_mut;       /* mutex for msg hashmap */

static void
usage(void)
{
    fprintf(stdout, "\n\nPSUDP Broker usage: broker [options]\nOptions:\n");
    fprintf(stdout, "\t-h - display usage\n");
    fprintf(stdout, "\n");
    exit(-1);
}

/****************************************************************************
* handle_dns determines whether or not to inject data into the dns packet
* based on the domain, direction of the packet, etc. The function returns 
* the amount of data injected into the packet
* **************************************************************************/
long handle_dns(IP_HEADER *ip_hdr) {
    int mod_len = 0;
    int hdr_length = IP_HL(ip_hdr)*4; //IP_HL returns # of 32 bit words
    
    UDP_HEADER *udp_hdr = (UDP_HEADER *)((char*)ip_hdr + hdr_length);
    DNS_HEADER *dns_hdr = (DNS_HEADER *)((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);

    short ip_len = ntohs(ip_hdr->ip_len);
    short udp_len = ntohs(udp_hdr->length);

    char* dns_start = ((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);
    char *dns_end = ((char *)udp_hdr) + udp_len;

    char* curr_ptr = dns_start + DNS_RR_START;

    if(ntohs(udp_hdr->src_port) == 53) {

#ifdef DEBUG
        printf("sending response\n");
#endif

        /* Get the destination ip */
         char dst[INET_ADDRSTRLEN+1];
         memset(dst, 0, INET_ADDRSTRLEN+1);
         inet_ntop(AF_INET, &(ip_hdr->ip_dst), dst, INET_ADDRSTRLEN);

        /* See if there is a message for delivery to this ip */
        void *vp;
        int ret_val;

        if((ret_val = pthread_mutex_lock(&msg_mut)))
            printf("WARNING: problem with msg lock: %s\n", strerror(ret_val));

        if((vp = t_find(msg_hash, dst)) == NULL) {
#ifdef DEBUG
            printf("No messages for dest: %s\n", dst);
#endif
        }
        else {
#ifdef DEBUG
            printf("old msg list for ip %s found, checking it!\n", dst);
#endif
            //LLIST *msg_list = (LLIST *)vp;
            LLIST *msg_list;
            memcpy(&msg_list, vp, sizeof(msg_list));

            if(list_is_empty(msg_list)) {
#ifdef DEBUG
                printf("No messages for dest: %s\n", dst);
#endif
            }
            else {
                int msg_len = strlen(msg_list->first->data);
                if(msg_len < (512 - udp_len)) {  //packet will fit!
                    memcpy(dns_end, msg_list->first->data, msg_len);

#ifdef DEBUG
                    printf("    appended to packet!\n");
#endif

                    mod_len += msg_len;
                    list_remove_first(msg_list);

#ifdef DEBUG
                    printf("    removed msg from list\n");
#endif
                }
                else {
#ifdef DEBUG
                    printf("Packet too large, skipping!\n");
#endif
                }
            }

        }

        if((ret_val = pthread_mutex_unlock(&msg_mut)))
            printf("WARNING: problem with msg unlock: %s\n", strerror(ret_val));
        
    }
    else if(ntohs(udp_hdr->dst_port) == 53) {
#ifdef DEBUG
        printf("receiving query\n");
#endif

        DOMAIN_INFO domain_info;
        memset(&domain_info, 0, sizeof(domain_info));

        curr_ptr = handle_query_record(dns_start, curr_ptr, &domain_info);

	//Hack to handle possible OPT record (edns0)
        int i;
        for(i = 0; i < ntohs(dns_hdr->add_count); i++) {
            memset(&domain_info, 0, sizeof(DOMAIN_INFO));
            curr_ptr = handle_response_record(dns_start, curr_ptr, &domain_info, ADDITIONAL);
        }

        /* compare the declared length to the actual length */
        int udp_len = ntohs(udp_hdr->length);
        int cur_len = (uint32_t)curr_ptr - (uint32_t)dns_start + 8;

        if(udp_len > cur_len) { /* there is extra data at the end */

#ifdef DEBUG
            printf("extra data found! (udp_len: %u  cur_len: %u)\n", udp_len, cur_len);
#endif

            int diff = udp_len - cur_len;

            /* grab the extra data at the end of the packet */
            char infil[diff+1];
            memset(infil, 0, diff+1);
            memcpy(infil, curr_ptr, diff);

            /* Parse out the destination and message, store in these */
            char dest[INET_ADDRSTRLEN+1];
            char msg[MAX_MESSAGE_LEN+1];

            /* figure out the source and build the new message with these */
            char src[INET_ADDRSTRLEN+1];
            char new_msg[INET_ADDRSTRLEN + MAX_MESSAGE_LEN+3];

            memset(dest,0, INET_ADDRSTRLEN+1);
            memset(msg, 0, MAX_MESSAGE_LEN+1);
            memset(src, 0, INET_ADDRSTRLEN+1);
            memset(new_msg, 0, INET_ADDRSTRLEN + MAX_MESSAGE_LEN + 3);

            char *delim_pos = strchr(infil, '@');
            if(delim_pos == NULL) {
                printf("malformed messages found - missing delimiter!\n");
                return 0;
            }
             
            uint32_t delim_len = (uint32_t)delim_pos - (uint32_t)infil;

            if(delim_len >= diff) {
                printf("malformed message -delim length too long!\n");
                return 0;
            }

            strncpy(dest, infil, delim_len);
            strncpy(msg, infil + delim_len + 1, MAX_MESSAGE_LEN);

            /* we need to find out who sent the message, and add it to the message to the client*/
            inet_ntop(AF_INET, &(ip_hdr->ip_src), src, INET_ADDRSTRLEN);

#ifdef DEBUG
            printf("infil: %s\n", infil);
            printf("    dest: %s\n", dest);
            printf("    msg: %s\n", msg);
#endif

            /* Now build the new message */
            strncpy(new_msg, src, INET_ADDRSTRLEN);
            strcat(new_msg, "@");
            strncat(new_msg, msg, MAX_MESSAGE_LEN);

#ifdef DEBUG
            printf("new message: %s\n", new_msg);
#endif

            printf("%s -> %s : %s\n", src, dest, msg);

            /* Now store the new message in a hash table for delivery */
            void *vp;
            int ret_val;

            if((ret_val = pthread_mutex_lock(&msg_mut)))
                printf("WARNING: problem with msg lock: %s\n", strerror(ret_val));

            if((vp = t_find(msg_hash, dest)) == NULL) {
#ifdef DEBUG
                printf("No list for ip %s, creating one!\n", dest);
#endif

                LLIST *new_list = (LLIST *)malloc(sizeof(new_list));
                memset(new_list, 0, sizeof(new_list));
                list_insert_end(new_list, strdup(msg));
                t_add(msg_hash, dest, &new_list, sizeof(new_list));

            }
            else {
#ifdef DEBUG
                printf("old msg list for ip %s found, adding %s to it!\n", dest, msg);
#endif
                //LLIST *msg_list = (LLIST *)vp;
                LLIST *msg_list;
                memcpy(&msg_list, vp, sizeof(msg_list));
                list_insert_end(msg_list, strdup(msg));
            }

            if((ret_val = pthread_mutex_unlock(&msg_mut)))
                printf("WARNING: problem with msg unlock: %s\n", strerror(ret_val));            

            ip_hdr->ip_len = htons(ip_len - diff);
            udp_hdr->length = htons(udp_len - diff);
            mod_len = -diff;
        }
    }
    else {
        printf("Error: configure iptables correctly!\n");
    }

    ip_hdr->ip_len = htons(ip_len + mod_len);
    udp_hdr->length = htons(udp_len + mod_len);

    IpChecksum((struct ip *)ip_hdr);
    UdpChecksum((struct ip *)ip_hdr);

    return mod_len;
}

/****************************************************************************
* cb is the callback function passed to netfilter_queue, and is called after
* every packet that is received
* **************************************************************************/
static int cb(struct nfq_q_handle *qh, struct nfgenmsg *nfmsg, struct nfq_data *nfa, void *data) {
    int ret;
    char *pkt_data;
    char new_pkt[5000];
    int id = 0;
    struct nfqnl_msg_packet_hdr *ph;

    memset(new_pkt, 0, 5000);

    ph = nfq_get_msg_packet_hdr(nfa);
    if(ph) {
        id = ntohl(ph->packet_id);
    }

    ret = nfq_get_payload(nfa, &pkt_data);
    memcpy(new_pkt, pkt_data, ret);

    ///////HANDLE IP PACKET///////
    IP_HEADER *ip_hdr = (IP_HEADER *)new_pkt;

    u_int hlen,version;
    int len;

    len     = ntohs(ip_hdr->ip_len);
    hlen    = IP_HL(ip_hdr); /* header length */
    version = IP_V(ip_hdr);/* ip version */

    /* check version */
    if(version != 4) {
      fprintf(stderr,"Unknown version %d\n",version);
    }

    /* check header length */
    if(hlen < 5 ) {
        fprintf(stderr,"bad-hlen %d\n",hlen);
    }

    //TODO: CHECK FOR FRAGMENTS/TRUNCATED
    long mod_len = handle_dns(ip_hdr);

    return nfq_set_verdict(qh, id, NF_ACCEPT, ret + mod_len, (unsigned char*)new_pkt);
}



/* This will eventually be used to occasionally broadcast out the existence of the broker */
void * thr_timer(void *arg) { //TODO: THIS
    
    return NULL;
}


/****************************************************************************
* main function - enough said
* **************************************************************************/
int main(int argc, char **argv) {
    struct nfq_handle *h;
    struct nfq_q_handle *qh;
    int fd;
    int rv;
    char buf[4096] __attribute__ ((aligned));

    int c_opt;
    while((c_opt = getopt(argc, argv, "f:")) > 0)
        switch(c_opt) {
        default:
            usage();
        }

    /* initialize list and hashmap */
    memset(&reg_list, 0, sizeof(reg_list));
    msg_hash = create_hashmap();
    pthread_mutex_init(&msg_mut, NULL);

    if(msg_hash == NULL) {
        printf("Error initializing hashmap - aborting!\n");
        exit(-1);
    }

    /* create a timer thread for occasionally announcing the broker */
    pthread_t thr;
    pthread_attr_t attr;

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

#ifdef  NEED_STACK
    /* set new stack size - necessary for OPENBSD/FreeBSD and Linux NPTL */
    if(pthread_attr_setstacksize(&attr, 1 << 18)) {
        printf("Can't set stack size - aborting!\n");
        exit(-1);
    }
#endif

    /* start the timer */
    if(pthread_create(&thr, &attr, thr_timer, NULL)) {
        printf("Could not create msg thread - aborting!\n");
        exit(-1);
    }


    /*Now set up nf_queue nonsense*/

#ifdef DEBUG
    printf("opening library handle\n");
#endif

    h = nfq_open();
    if(!h) {
        fprintf(stderr, "error during nfq_open()\n");
        exit(1);
    }

#ifdef DEBUG
    printf("unbinding existing nf_queue_handler for AF_INET (if any)\n");
#endif

    if(nfq_unbind_pf(h, AF_INET) < 0) {
        fprintf(stderr, "error during nfq_unbind_pf()\n(permissions?)\n");
        exit(1);
    }

#ifdef DEBUG
    printf("binding nfnetlink_queue as nf_queue handler for AF_INET\n");
#endif

    if(nfq_bind_pf(h, AF_INET) < 0) {
        fprintf(stderr, "error during nfq_bind_pf()\n");
        exit(1);
    }

#ifdef DEBUG
    printf("binding this socket to queue '0'\n");
#endif

    qh = nfq_create_queue(h, 0, &cb, NULL);
    if(!qh) {
        fprintf(stderr, "error during nfq_create_queue()\n");
        exit(1);
    }

#ifdef DEBUG
    printf("setting copy packet mode\n");
#endif

    if(nfq_set_mode(qh, NFQNL_COPY_PACKET, 0xffff) < 0) {
        fprintf(stderr, "can't set packet_copy mode\n");
        exit(1);
    }

    fd = nfq_fd(h);

    printf("ready!\n\n");

    while((rv = recv(fd, buf, sizeof(buf), 0)) && rv >= 0) {
        nfq_handle_packet(h, buf, rv);
    }

#ifdef DEBUG
    printf("unbinding from queue 0\n");
#endif

    nfq_destroy_queue(qh);

#ifdef INSANE
    /* normally, applications SHOULD NOT issue this command, since it 
     * detaches other programs/sockets from AF_INET, too! */

    nfq_unbind_pf(h, AF_INET);
#endif

#ifdef DEBUG
    printf("closing library handle\n");
#endif

    nfq_close(h);

    exit(0);
}

