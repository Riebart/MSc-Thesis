iptables -F
iptables -t mangle -A POSTROUTING -p udp --dport 53 -j NFQUEUE
