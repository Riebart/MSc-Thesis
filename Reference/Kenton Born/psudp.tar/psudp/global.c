/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"

/* search for a host name, return the addrinfo for it */
int get_host(char *const name, struct addrinfo *res) {
    struct addrinfo *chain, *ap;
    struct addrinfo hints;
    int ret_val;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = PF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_CANONNAME;
    if((ret_val = getaddrinfo(name, NULL, &hints, &chain)) == 0) {
        for(ap = chain; ap != NULL; ap = ap-> ai_next)
            if(ap->ai_socktype == SOCK_STREAM)
                break;
        if(ap == NULL) {
            freeaddrinfo(chain);
            return EAI_NONAME;
        }
        *res = *ap;
        if((res->ai_addr = (struct sockaddr *)malloc(ap->ai_addrlen)) == NULL) {
            freeaddrinfo(chain);
            return EAI_MEMORY;
        }
        memcpy(res->ai_addr, ap->ai_addr, ap->ai_addrlen);
        freeaddrinfo(chain);
    }

    return ret_val;
}
