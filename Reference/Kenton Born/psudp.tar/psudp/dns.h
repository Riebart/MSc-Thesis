/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef dns_h
#define dns_h

#include "global.h"

char* parse_labels(char* start_loc, char* curr_ptr, LLIST *label_list);
void get_domain_info(LLIST *label_list, DOMAIN_INFO *domain_info);

char* handle_query_record(char *dns_start, char *curr_ptr, DOMAIN_INFO *domain_info);
char* handle_response_record(char *dns_start, char *curr_ptr, DOMAIN_INFO * domain_info, int rr_type);


#endif
