iptables -F
iptables -t mangle -A INPUT -p udp --dport 53 -j NFQUEUE
iptables -t mangle -A POSTROUTING -p udp --sport 53 -j NFQUEUE
