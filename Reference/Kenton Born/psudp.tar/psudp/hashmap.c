/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

//Hashing code derived from Pound - http://www.apsis.ch/pound

#include "broker.h"

/*
 * basic hashing function, based on fmv
 */
unsigned long
t_hash(const TABNODE *e)
{
    unsigned long   res;
    char            *k;

    k = e->key;
    res = 2166136261;
    while(*k)
        res = (res ^ *k++) * 16777619;
    return res;
}
IMPLEMENT_LHASH_HASH_FN(t_hash, const TABNODE *)

int
t_cmp(const TABNODE *d1, const TABNODE *d2)
{
    return strcmp(d1->key, d2->key);
}
IMPLEMENT_LHASH_COMP_FN(t_cmp, const TABNODE *)


/*
 * Add a new key/content pair to a hash table
 * the table should be already locked
 */
void
t_add(LHASH *const tab, const char *key, const void *content, const size_t cont_len)
{
    TABNODE *t, *old;

    if((t = (TABNODE *)malloc(sizeof(TABNODE))) == NULL) {
        printf("WARNING: malloc error in t_add()\n");
        return;
    }
    if((t->key = strdup(key)) == NULL) {
        free(t);
        printf("WARNING: strdup error in t_add()\n");
        return;
    }
    if((t->content = malloc(cont_len)) == NULL) {
        free(t->key);
        free(t);
        printf("WARNING: malloc error in t_add()\n");
        return;
    }
    memcpy(t->content, content, cont_len);
    t->last_acc = time(NULL);
    if((old = (TABNODE *)lh_insert(tab, t)) != NULL) {
        free(old->key);
        free(old->content);
        free(old);
        printf("WARNING: dup() error in t_add()\n");
    }
    return;
}

/*
 * Find a key
 * returns the content in the parameter
 * side-effect: update the time of last access
 */
void *
t_find(LHASH *const tab, char *const key)
{
    TABNODE t, *res;

    t.key = key;
    if((res = (TABNODE *)lh_retrieve(tab, &t)) != NULL) {
        res->last_acc = time(NULL);
        return res->content;
    }
    return NULL;
}


/*
 * Delete a key
 */
void
t_remove(LHASH *const tab, char *const key)
{
    TABNODE t, *res;

    t.key = key;
    if((res = (TABNODE *)lh_delete(tab, &t)) != NULL) {
        free(res->key);
        free(res->content);
        free(res);
    }
    return;
}

static void
t_old(TABNODE *t, void *arg)
{
    ALL_ARG *a;

    a = (ALL_ARG *)arg;
    if(t->last_acc < a->lim)
        lh_delete(a->tab, t);
    return;
}
IMPLEMENT_LHASH_DOALL_ARG_FN(t_old, TABNODE *, void *)


/*
 * Expire all old nodes
 */
void
t_expire(LHASH *const tab, const time_t lim)
{
    ALL_ARG a;
    int down_load;

    a.tab = tab;
    a.lim = lim;
    down_load = tab->down_load;
    tab->down_load = 0;
    lh_doall_arg(tab, LHASH_DOALL_ARG_FN(t_old), &a);
    tab->down_load = down_load;
    return;
}

static void
t_cont(TABNODE *t, void *arg)
{
    ALL_ARG *a;

    a = (ALL_ARG *)arg;
    if(memcmp(t->content, a->content, a->cont_len) == 0)
        lh_delete(a->tab, t);
    return;
}
IMPLEMENT_LHASH_DOALL_ARG_FN(t_cont, TABNODE *, void *)

/*
 * Remove all nodes with the given content
 */
void
t_clean(LHASH *const tab, void *const content, const size_t cont_len)
{
    ALL_ARG a;
    int down_load;

    a.tab = tab;
    a.content = content;
    a.cont_len = cont_len;
    down_load = tab->down_load;
    tab->down_load = 0;
    lh_doall_arg(tab, LHASH_DOALL_ARG_FN(t_cont), &a);
    tab->down_load = down_load;
    return;
}

LHASH* create_hashmap(void) {
    return lh_new(LHASH_HASH_FN(t_hash), LHASH_COMP_FN(t_cmp));
}
