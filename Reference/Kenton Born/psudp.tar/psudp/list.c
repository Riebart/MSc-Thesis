/*
PSUDP - a messaging system that piggy-backs on legitimate DNS traffic
Copyright (c) 2010 Kenton Born

Author: Kenton Born
Contact: kenton@kentonborn.com

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

//This file is derived from en.literateprograms.org/Singly_linked_list(c)

#include "list.h"


/* Create a node, allocation left to user */
static NODE* 
node_create(char *data) {
    NODE *node;
    if(!(node=malloc(sizeof(NODE))))
        return NULL;
    node->data = data;
    node->next = NULL;
    return node;
}


/* insert node at end of list */
void list_insert_end(LLIST *list, char *data) {
    NODE *newnode;
    if((newnode = node_create(data)) == NULL) {
        fprintf(stderr,"could not allocate node, exiting");
        exit(1);
    }

    NODE *curr_node = list->first;
    if(curr_node == NULL) {
        list->first = newnode;
    }
    else {      
        while(curr_node->next) {
            curr_node = curr_node->next;
        }
        curr_node->next = newnode;
    }
    list->num_elements++;
}


/* insert node at beginning of list */
void list_insert_beginning(LLIST *list, char *data) {
    NODE *newnode;
    newnode = node_create(data);

    newnode->next = list->first;
    list->first = newnode;
    list->num_elements++;
}


/* insert node in middle of list */
void list_insert_after(LLIST *list, NODE *node, char *data) {
    NODE *newnode;
    newnode = node_create(data);

    newnode->next = node->next;
    node->next = newnode;
    list->num_elements++;
}


/* removes a node, returns 1 on success */
int list_remove(LLIST *list, NODE *node) {
    NODE *curr_node = list->first;
    
    if(curr_node == NULL)
        return 0;

    if(curr_node == node) {
        list->first = node->next;
        free(node->data);
        free(node);
        list->num_elements--;
        return 1;
    }

    while(curr_node->next && curr_node->next != node)
        curr_node = curr_node->next;

    if(curr_node->next) {
        curr_node->next = node->next;
        free(node);
        list->num_elements--;
        return 1;
    }
    else
        return 0;
}

/* removes the first element of the list, returns 1 on success */
int list_remove_first(LLIST *list) {
    NODE *curr_node = list->first;

    if(curr_node != NULL) {
        NODE *temp = curr_node->next;
        free(curr_node->data);
        free(curr_node);
        list->first = temp;
        list->num_elements--;
        return 1;
    }
    else
        return 0;
}

/* remove all the elements from the list */
void list_clear(LLIST *list) {
    if(!list->first)
        return;

    NODE *curr_node = list->first;
    NODE *next_node;
    
    while(curr_node) {
        next_node = curr_node->next;
        free(curr_node->data);
        free(curr_node);
        curr_node = next_node;
    }
}

/* returns address of node containing the data (0, otherwise) */
NODE *list_find(LLIST *list, char *data) {
    NODE *curr_node = list->first;

    while(curr_node) {
        if(strncmp(curr_node->data, data, strlen(data)) == 0)
            return curr_node;
        curr_node = curr_node->next;
    }
    return NULL;
}

/* returns 1 when the list is empty and 0, otherwise */
int list_is_empty(LLIST *list) {
    if(list->num_elements)
        return 0;
    else
        return 1;
}
