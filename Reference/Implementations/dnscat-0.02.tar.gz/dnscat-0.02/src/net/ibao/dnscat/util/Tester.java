/* Tester class for AsyncInputStream
 * Author: Tadeusz Pietraszek (tadek@pietraszek.org)
 * $Id: Tester.java 52 2005-08-26 15:11:37Z tadekp $
 */
package net.ibao.dnscat.util;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

/**
 * Tester class for AsyncInputStream
 * @author Tadeusz Pietraszek (tadek@pietraszek.org)
 * @version $Id: Tester.java 52 2005-08-26 15:11:37Z tadekp $
 */
public class Tester {
    private static Logger logger = Logger
            .getLogger(AsyncInputStream.class);

    static public void main(String[] argv) {
        try {
            BasicConfigurator.configure();

            AsyncInputStream a = new AsyncInputStream(10);
            int i;
            int cnt = 10;
            while ( (cnt >= 0) && (!a.isEOF()) ) {

                if (a.available() == 0) {
                    try {
                        //logger.debug("thread sleeping - no data");
                        System.err.print('.');
                        cnt--;
                        Thread.sleep(1000);
                    } catch (InterruptedException ie) {
                    }
                    continue;
                }

                logger.info("ok i=" + a.available());
				
                byte b[] = new byte[10];
                int r = a.read(b);
                System.err.println("---> " + r + " " + ArrayToString.get(b,r));
            }
            logger.info("All done - program terminating");

            a.terminate();
            logger.info("really done");
        } catch(Exception e) {logger.error("error",e);
            
        }

    }

}
