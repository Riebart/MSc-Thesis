/**
 * Asynchronous (non-blocking) operations on stdin or other FileInputStreams.
 * 
 * Copywirght (c) 2004 Tadeusz Pietraszek (tadek@pietraszek.org)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: AsyncInputStream.java 42 2005-08-18 09:37:47Z tadekp $
 */
package net.ibao.dnscat.util;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ClosedByInterruptException;
//import org.apache.log4j.Logger;


/**
 * This class provides a convenient way of accessing stdin and other FileInputStreams
 * in a non blocking fashion. The implementation uses java.nio and threads to achieve this 
 * @version $Id: AsyncInputStream.java 42 2005-08-18 09:37:47Z tadekp $
 * @author Tadeusz Pietraszek (tadek@pietraszek.org)
 */
public class AsyncInputStream implements Runnable {
    //private static Logger logger = Logger.getLogger(AsyncInputStream.class);
    private FileInputStream fIn;	
    private ByteBuffer readBuff;
    private ByteBuffer threadBuff;
    private boolean eof;
    private IOException ioError;
    private Thread thread;
    
    /** Constructs the wrapper on stdin with a given bufferSize (the class won't return more data than this in one read)
     * @param bufferSize the size of the internal buffer
     */
    public AsyncInputStream(int bufferSize) {
        this(new FileInputStream(FileDescriptor.in), bufferSize);
    }
    
    /** Constructs the wrapper on stdin with a given bufferSize (the class won't return more data than this in one read)
     * @param fileInput FileInput stream to read (probably makes sense with stdin and named pipes)
     * @param bufferSize the size of the internal buffer
     */
    public AsyncInputStream(FileInputStream fileInput, int bufferSize) {
        //logger.debug("constructing " + bufferSize);
        
        fIn = fileInput;
        
        readBuff = ByteBuffer.allocate(bufferSize);
        readBuff.flip();								//make it ready to read
        threadBuff = ByteBuffer.allocate(bufferSize);
        threadBuff.flip();								//make it ready to read
        
        eof = false;
        ioError = null;

        thread = new Thread(this);
        thread.start(); /* start a thread */
    }
    
    /** Returns number of bytes immediately available
     * @return the number of bytes available (note that read can actually return more)
     */
    public synchronized int available() {
        return readBuff.remaining();
    }
    
    
    /** Checks for end of file contidion (or thread termination)
     * @return true == there will be no more data to read
     */
    public synchronized boolean isEOF() {
        return ((available() == 0) && eof);
    }
    
    /** Read at most b.length bytes into the buffer. If there's not data immediatelly available - block until there is some 
     * (should check available() first). Error is returned if the worker thread detected error. Note that the errror condition
     * is detected only if there's no data available.
     *  
     * @param b Input buffer
     * @return number of bytes actually read
     * @throws Exception The exception that has occurred (only if no data is immediately available)
     * @throws InterruptedException Blocking call has been interrupted (YESSS - it's possible!)
     */
    public synchronized int read(byte[] b)  throws Exception {
        //logger.debug("read called with "+b.length+" bytes");
        
        if ((b == null) || (b.length == 0))
            throw new IOException("Null or zero-sized input buffer");

        while (!readBuff.hasRemaining()) {
            if (ioError != null)	//no data is available and error has occurred
                throw ioError;

            if (eof) {
                //logger.debug("terminating read - thread finished");
                return -1;
            }
            //logger.debug("buffer is empty, about to sleep");
            wait(0);				//can be interrupted! 
            //logger.debug("woken up");
        }

        int toCopy = readBuff.remaining();
        if (toCopy > b.length)
            toCopy = b.length;
        
        readBuff.get(b,0, toCopy);
        
        //logger.debug("calling notify: "+toCopy);
        notify();

        return toCopy;
    }

    
    
    /** Terminate the thread (and close the stream)
     * 
     */
    public synchronized void terminate() {
        eof = true; 		//set terminate flag
        notify(); 			//wake up
        thread.interrupt(); 	//try to interrupt blocking system call
    }

    /** Main worker loop.
     * @see java.lang.Runnable#run()
     */
    public void run() {
        //logger.debug("thread started");

        FileChannel fc = fIn.getChannel();
        
        try {
            while (!eof) {
                //logger.debug("about to read");
                threadBuff.clear();
                int readCnt = fc.read(threadBuff);
                threadBuff.flip();
                //logger.debug("read status: " + readCnt);
                
                synchronized (this) {
                    if (readCnt < 0) {
                        eof = true;
                        //logger.debug("finishing - about to notify");
                        notify();		//just in case the other one waits on read
                        break;
                    }                

                    //here readBuff is in a read stage - check if have enough space
                    while ( (readBuff.capacity() - readBuff.limit() + readBuff.position()) < threadBuff.limit() ) {
                        //logger.debug("readBuff has less space than needed, sleeping");
                        wait(0);
                        //logger.debug("woken up");
                    }
                
                	//ok, there's enough space in readBuff to put everything
                    readBuff.compact();		//get it ready to write
                    readBuff.put(threadBuff);
                    readBuff.flip();		//now it's ready to read
                    
                    //logger.debug("about to notify");
                    notify();
                } //synchronized
             } //while loop
            fIn.close();
        } 
        catch (ClosedByInterruptException cie) {}	//do nothing - we know we're done
        catch (InterruptedException ie) {}			//it's also ok
        catch (IOException e) {						//that's something different - read error?
            //logger.error("IOError ",e);
            ioError = e;
        }
        eof = true;		//mark that we're done
        //logger.debug("thread done");
    }
}

