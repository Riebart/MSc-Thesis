/* DNScatServer main file
 * Copyright (c) 2004 Tadeusz Pietraszek
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: DNScatServer.java 42 2005-08-18 09:37:47Z tadekp $
 */

package net.ibao.dnscat;

import gnu.getopt.Getopt;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Properties;

import net.ibao.dnscat.util.AsyncInputStream;
import net.ibao.dnscat.util.EncodingEnvelope;
import net.ibao.dnscat.util.SixBitDNSEncoder;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.xbill.DNS.ARecord;
import org.xbill.DNS.CNAMERecord;
import org.xbill.DNS.DClass;
import org.xbill.DNS.Flags;
import org.xbill.DNS.Header;
import org.xbill.DNS.Message;
import org.xbill.DNS.Name;
import org.xbill.DNS.OPTRecord;
import org.xbill.DNS.Opcode;
import org.xbill.DNS.Rcode;
import org.xbill.DNS.Record;
import org.xbill.DNS.SOARecord;
import org.xbill.DNS.Section;
import org.xbill.DNS.SetResponse;
import org.xbill.DNS.Type;

/**
 * The main class of DNScatServer
 * @version $Id: DNScatServer.java 42 2005-08-18 09:37:47Z tadekp $ 
 * @author Tadeusz Pietraszek (tadek@pietraszek.org)
 */
public class DNScatServer {
    static Logger logger = Logger.getLogger(DNScatServer.class);
    static String DNS_CAT_VERSION = "Version 0.01 (28/10/2004)";
    static String DEFAULT_PROPERTY_FILE = "/DNScatServer.properties";
    static String LOGGER_PROPERTY_FILE = "/DNScatServerLogger.properties";
    private static int SOCK_TIMEOUT = 1000;

    /* variables initialized in the constructor */
    private Name domainName; 
    private InetAddress interfaceAddr;
    private int dnsPort;
    private boolean ignoreTimeouts;
    private boolean authoritative;
    private SOARecord authoritativeServData;
    private InetAddress ipAddr;
    private boolean randomizeIp;
    private long ttl;
    private int receiveTimeout;
    private int bufferSize;	//maximum length of data in one frame (both client and server)
    private EncodingEnvelope e;
    private	EncodingEnvelope d;

    
    private int receiveCredit;
    

    

    AsyncInputStream ais;

    boolean terminate = false; //flag telling the application to terminate

    SixBitDNSEncoder dnsEncoder = new SixBitDNSEncoder();

    
    Record lastCNAME = null; //we're caching the last response in case of
                             // retransmit

    public byte[] receiveRequest(byte[] send) throws Exception {

        logger.debug("received " + send.length + " bytes");

        System.out.write(send);

        byte[] rbuff = new byte[bufferSize];
        int rbuffRead = (ais.available() != 0) ? ais.read(rbuff) : 0;

        byte[] wbuff = new byte[rbuffRead];
        System.arraycopy(rbuff, 0, wbuff, 0, wbuff.length);

        logger.debug("sending " + wbuff.length + " bytes");

        return wbuff;
    }

    public void serveUDP(InetAddress addr, int port) {
        try {
            DatagramSocket sock = new DatagramSocket(port, addr);
            sock.setSoTimeout(SOCK_TIMEOUT); /*
                                              * enable non-blocking IO so that
                                              * we can exit on EOF with no input
                                              * data
                                              */

            final short udpLength = 512; //max DNS record size
            byte[] in = new byte[udpLength];

            DatagramPacket indp = new DatagramPacket(in, in.length);
            DatagramPacket outdp = null;

            /*
             * receiveCredit is a variable that determines when the program
             * timeouts. it's initialized when the first valid packet has been
             * received and it's decremented on each readTimeout. When it
             * reaches zero, the program terminates. Note that initially such
             * timer has a negative value which means it does not decrement -
             * the program can wait for an initial connection infinitelly
             */
            receiveCredit = -1;

            while (!terminate) {
                if (ais.isEOF()) {
                    logger.info("end of input stream - program terminating");
                    terminate = true;
                    break;
                }

                indp.setLength(in.length);
                try {
                    sock.receive(indp);
                } catch (SocketTimeoutException te) {
                    if (receiveCredit > 0) {
                        receiveCredit--;
                    } else if (receiveCredit == 0) {
                        logger.info("timeout reached - program terminating");
                        terminate = true;
                    }

                    continue;
                } catch (InterruptedIOException e) {
                    continue;
                }
                Message query;
                byte[] response = null;
                try {
                    query = new Message(in);
                    response = generateReply(query, in, indp.getLength(), null);
                    if (response == null)
                        continue;
                } catch (IOException e) {
                    response = formerrMessage(in);
                    e.printStackTrace();
                }
                if (outdp == null)
                    outdp = new DatagramPacket(response, response.length, indp
                            .getAddress(), indp.getPort());
                else {
                    outdp.setData(response);
                    outdp.setLength(response.length);
                    outdp.setAddress(indp.getAddress());
                    outdp.setPort(indp.getPort());
                }
                sock.send(outdp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    byte[] generateReply(Message query, byte[] in, int length, Socket s)
            throws IOException {
        Header header;
        boolean badversion;
        int maxLength;
        boolean sigonly;
        SetResponse sr;
        int flags = 0;

        header = query.getHeader();
        if (header.getFlag(Flags.QR))
            return null;
        if (header.getRcode() != Rcode.NOERROR)
            return errorMessage(query, Rcode.FORMERR);
        if (header.getOpcode() != Opcode.QUERY)
            return errorMessage(query, Rcode.NOTIMPL);

        Record queryRecord = query.getQuestion();

        if (s != null)
            maxLength = 65535; //TCP
        else
            maxLength = 512; //UDP

        OPTRecord queryOPT = query.getOPT(); //extended options

        Message response = new Message(query.getHeader().getID());
        response.getHeader().setFlag(Flags.QR);
        if (query.getHeader().getFlag(Flags.RD))
            response.getHeader().setFlag(Flags.RD);
        response.addRecord(queryRecord, Section.QUESTION);

        if (queryOPT != null) { 
          OPTRecord opt = new OPTRecord((short)4096, 0, (byte)0, 0);
          response.addRecord(opt, Section.ADDITIONAL); 
        }

        Name name = queryRecord.getName();
        int type = queryRecord.getType();
        int dclass = queryRecord.getDClass();

        if (!name.subdomain(domainName)) {
            //response.getHeader().setRcode(Rcode.NXDOMAIN);
            return response.toWire(maxLength);
        }

        if (authoritative) {
            response.getHeader().setFlag(Flags.AA); //since it's our domain, we're authoritative
            response.addRecord(authoritativeServData, Section.AUTHORITY);
        }
        
        if (type != Type.A && type != Type.CNAME) {
            response.getHeader().setRcode(Rcode.NXDOMAIN);
            return response.toWire(maxLength);
        }

        /* hande request */
        try {
            Name txt = name.relativize(domainName);
            
            /* if randomize IP address, do it */
            if (randomizeIp)
                ipAddr = generateRandomIP(txt.toString());
            
            byte[] b = dnsEncoder.decode(txt.toString());
            if (d.isEncoded(b)) { //ok, decoding normal request

                logger.debug("client request " + name);

                logger.info("packet " + d.getPacketSequence(b)+" system " + d.getSequence());
                int diff = d.getPacketSequenceDiff(b);
                logger.debug("difference: " + diff + " " + txt);

                // what do we do:

                // -1 - retransmit
                // 0 - advance, all ok
                // < -1 - old packet retransmit
                // > 0 - packet lost and the client gave up

                if (diff == 0) {
                    d.nextSequence();

                    if (!ignoreTimeouts)
                        receiveCredit = receiveTimeout; // reset timeout counter

                    String reply = dnsEncoder.encode(e.encode(receiveRequest(d
                            .decode(b))));
                    e.nextSequence();
                    Name qualified = new Name(reply, domainName);

                    Record rc = new CNAMERecord(name, DClass.IN, ttl, qualified);
                    Record r = new ARecord(qualified, DClass.IN, ttl, ipAddr);
                            
                    response.addRecord(rc, Section.ANSWER);
                    response.addRecord(r, Section.ANSWER);

                    lastCNAME = rc;
                } else if (diff == -1) {
                    //don't update the sequence, but resend the packet

                    logger.info("packet retransmit");

                    Record r = new ARecord(name, DClass.IN, ttl, ipAddr);
                    response.addRecord(lastCNAME, Section.ANSWER);
                    response.addRecord(r, Section.ANSWER);
                } else {
                    logger.info("sequence mismatch - resyncing sequences");
                    d.setSequence(d.getPacketSequence(b));
                    d.nextSequence();

                    String reply = dnsEncoder.encode(e.encode(receiveRequest(d
                            .decode(b))));
                    e.nextSequence();
                    Name qualified = new Name(reply, domainName);

                    Record rc = new CNAMERecord(name, DClass.IN, ttl, qualified);
                    Record r = new ARecord(qualified, DClass.IN, ttl, ipAddr);
                    response.addRecord(rc, Section.ANSWER);
                    response.addRecord(r, Section.ANSWER);
                    lastCNAME = rc;
                }
            } else if (e.isEncoded(b)) { //not, a normal request, can it be our
                                         // reply?
                logger.debug("bogus server lookup " + name);

                Record r = new ARecord(name, DClass.IN, ttl, ipAddr);
                response.addRecord(r, Section.ANSWER);

            } else
                throw new Exception("Not a valid request");
        } catch (Exception e) { //decoding error, etc.
            logger.warn("exception caught on query " + query, e);
            response.getHeader().setRcode(Rcode.NXDOMAIN);
            return response.toWire(maxLength);
        }
        return response.toWire(maxLength);
    }

    
    public InetAddress generateRandomIP(String s) throws UnknownHostException {
        int h = s.hashCode();
        return InetAddress.getByAddress(new byte[] {(byte)((h >> 24)&0xff),(byte)((h >> 16)&0xff),
                (byte)((h >> 8)&0xff), (byte)(h&0xff)});
    }
    
    public byte[] formerrMessage(byte[] in) {
        Header header;
        try {
            header = new Header(in);
        } catch (IOException e) {
            return null;
        }
        return buildErrorMessage(header, Rcode.FORMERR, null);
    }

    byte[] buildErrorMessage(Header header, int rcode, Record question) {
        Message response = new Message();
        response.setHeader(header);
        response.getHeader().setFlag(Flags.RD); /* it's a reply */
        for (int i = 0; i < 4; i++)
            response.removeAllRecords(i);
        if (rcode == Rcode.SERVFAIL)
            response.addRecord(question, Section.QUESTION);
        header.setRcode(rcode);
        return response.toWire();
    }

    public byte[] errorMessage(Message query, int rcode) {
        return buildErrorMessage(query.getHeader(), rcode, query.getQuestion());
    }

    /**
     * Parse parameters and construct the main object. The code is complicated
     * and ugly, but I really couldn't find a better way of doing it.
     * 
     * @param argv
     *            Runtime parameters to parse
     * @throws Exception
     *             When something went wrong.
     *  
     */
    public DNScatServer(String[] argv) throws Exception {
        Getopt g = new Getopt("DNScatServer", argv, "?ho:l:p:iaA:I:t:c:s:S:R:");
        int c;
        String arg;

        String parDomain = null, parInterfaceAddr = null, parDNSPort = null;
        String parAuthoritativeServData = null, parIpAddr = null, parTTL = null, parTimeout = null; 
        String parBuffSize = null, parSendPrefix = null, parRecvPrefix = null;
        boolean parAuthoritative = false, parIgnoreTimeouts = false;

        System.err.println("DNScatServer - tunneling data using DNS request. " + DNS_CAT_VERSION + "\n" 
                        + "Copyright (c) 2004 by Tadeusz Pietraszek (tadek@pietraszek.org).\n"
                        +"  DNScat comes with ABSOLUTELY NO WARRANTY; for detailssee LICENSE file.\n"
                        +"  This is free software, and you are welcome to redistribute it under certain\n"
                        +"  conditions; see LICENSE in the distibution package for details.\n");

        try {
            Properties p = new Properties();
            try {
                p.load(getClass().getResourceAsStream(DEFAULT_PROPERTY_FILE));
            } catch (Exception e) {
                throw new Exception("Problem loading property file: "
                        + DEFAULT_PROPERTY_FILE);
            }
            if (p.isEmpty())
                throw new Exception("Property file " + DEFAULT_PROPERTY_FILE
                        + " is empty.");

            /* read default options */
            parDomain = p.getProperty("DOMAIN");
            parInterfaceAddr = p.getProperty("INTERFACE");
            parDNSPort = p.getProperty("DNS_PORT");
            parAuthoritativeServData= p.getProperty("AUTHORITATIVE_DATA");
            parIpAddr = p.getProperty("IP");
            parTTL = p.getProperty("TTL");
            parTimeout = p.getProperty("TIMEOUT");
            parBuffSize = p.getProperty("BUFF_SIZE");
            parSendPrefix = p.getProperty("SEND_PREFIX");
            parRecvPrefix = p.getProperty("RECV_PREFIX");
            String tmp = p.getProperty("AUTHORITATIVE");
            parAuthoritative =  (tmp != null)&& Boolean.valueOf(tmp).booleanValue();
            tmp = p.getProperty("IGNORE_TIMEOUTS");
            parIgnoreTimeouts = (tmp != null)&& Boolean.valueOf(tmp).booleanValue();

            if (parDomain != null)
                parDomain = parDomain.trim();

            while ((c = g.getopt()) != -1) {
                switch (c) {
                case 'h':
                case '?':
                    throw new Exception("Invalid Arguments");
                case 'o':
                    parDomain = g.getOptarg();
                    break;
                case 'l':
                    parInterfaceAddr = g.getOptarg();
                    break;
                case 'p':
                    parDNSPort = g.getOptarg();
                    break;
                case 'A':
                    parAuthoritativeServData = g.getOptarg();
                    break;
                case 'I':
                    parIpAddr = g.getOptarg();
                    break;
                case 't':
                    parTTL = g.getOptarg();
                    break;
                case 'c':
                    parTimeout = g.getOptarg();
                    break;
                case 's':
                    parBuffSize = g.getOptarg();
                    break;
                case 'S':
                    parSendPrefix = g.getOptarg();
                    break;
                case 'R':
                    parRecvPrefix = g.getOptarg();
                    break;
                case 'a':
                    parAuthoritative = true;
                    break;
                case 'i':
                    parIgnoreTimeouts = true;
                    break;
                default:
                    throw new Exception("getopt() returned " + c + "\n");
                }
            }

            //now validate options
            if ((parDomain == null) || (parDomain.endsWith(".")))
                throw new Exception("Invalid domain name: " + parDomain);
            domainName = Name.fromString(parDomain + ".");
            logger.info("Using domain name: " + domainName);

            //
            String[] servers;
            if (parInterfaceAddr != null)
                interfaceAddr = InetAddress.getByName(parInterfaceAddr);
            else
                interfaceAddr = InetAddress.getByName("0.0.0.0");
            logger.info("Listening on interface: " + interfaceAddr);

            //
            if (parDNSPort != null)
                dnsPort = Integer.parseInt(parDNSPort);
            else
                dnsPort = 53;


            //
            ignoreTimeouts = parIgnoreTimeouts;
            
            //
            authoritative = parAuthoritative;
            
            //
            if (authoritative) {
            	if (parAuthoritativeServData == null)
            	    throw new Exception("Authoritative mode requested, but authoritative record not defined");
                String[] parms = parAuthoritativeServData.split(parAuthoritativeServData);
                if (parms.length != 8)
                    throw new Exception("Need exacty 8 comma separated parameters in authoritative section: " +
                    		"ttl,host,admin,serial,refresh,retry,expire,minimum"); 
                
                /* SOARecord(Name name, int dclass, long ttl, Name host, Name admin,
                 *    long serial, long refresh, long retry, long expire, long minimum)
                 */
                authoritativeServData = new SOARecord(domainName,DClass.IN, Long.parseLong(parms[0]), Name.fromString(parms[1]),
                          Name.fromString(parms[2]), Long.parseLong(parms[3]), Long.parseLong(parms[4]), Long.parseLong(parms[5]),
                          Long.parseLong(parms[6]), Long.parseLong(parms[7]));
                logger.info("Authoritative record: "+authoritativeServData);
            }
            
            //
            if (parIpAddr != null) {
                ipAddr = InetAddress.getByName(parIpAddr);
                randomizeIp = ipAddr.isAnyLocalAddress();
            }
            else
                throw new Exception("IP address not defined. Use 0.0.0.0 for random");
            
            //
            if (parTTL != null)
                ttl = Long.parseLong(parTTL);
            else
                throw new Exception("TTL not defined");

            //
            if (parTimeout != null)
                receiveTimeout = Integer.parseInt(parTimeout);

            if (parBuffSize == null)
                throw new Exception("Buffer size not defined");
            bufferSize = Integer.parseInt(parBuffSize);
            if ((bufferSize < 5) || (bufferSize > 200))
                throw new Exception("bufferSize < 5 or bufferSize > 200 error");

            //
            if (parSendPrefix == null)
                throw new Exception("Send prefix is null!");

            if (parRecvPrefix == null)
                throw new Exception("Receive prefix is null!");

            if (parSendPrefix.startsWith(parRecvPrefix)
                    || parRecvPrefix.startsWith(parSendPrefix))
                throw new Exception(
                        "Send and receive prefix should not be substrings of each other.");

            e = new EncodingEnvelope(parSendPrefix);
            d = new EncodingEnvelope(parRecvPrefix);

        } catch (Exception e) {
            System.err.println("\nDNScatClient [-o <domain name>][-l <address>][-p <port>][-i][-a]\n"+
                            "             [-A <data>][-I <ip addr>][-t <ttl>][-c <timeout>][-s <buffer size>]\n"+
                            "             [-S <prefix>][-R <prefix>]\n\n"+
                            "	-h, -? - print this screen\n"+
                            "	-o <domain name> - domain name that is delegated to the server ("+ parDomain+")\n"+
                            "	-l <interface address> - interface to listen on ("+parInterfaceAddr+")\n"+
                            "	-p <dns port> - DNS port to use (" + parDNSPort + ")\n"+
                            "	-i - ignore out of sync ("+ parIgnoreTimeouts+ ")\n"+
                            "	-a - use authoritative reply ("+parAuthoritative+")\n"+
                            "	-A <authoritative data> - set authoritative data ("+parAuthoritativeServData+")\n"+
                            "	-I <ip address to generate> ("+parIpAddr+")\n"+
                            "   -t <ttl> - set time to live ("+parTTL+")\n" +
                            "	-c <timeout> - set communication timeout ("+parTimeout+")\n"+  
                            "	-s <buffer size> - buffer size ("+ parBuffSize+ ")\n"+
                            "	-S <prefix> - send prefix ("+ parSendPrefix+")\n"+
                            "	-R <prefix> - recieve preifx ("+ parRecvPrefix+ ")\n" +
                            "\n");
            throw e;
        }
    }

    public boolean run() {
        try {
            ais = new AsyncInputStream(bufferSize);
            serveUDP(interfaceAddr, dnsPort);
        }
        catch (Exception e) {
            logger.error("Exception has occurred. System terminating", e);
            return false;
        }
        finally{
            ais.terminate();
        }
        return true;
    }

    static public void main(String[] argv) throws Exception {
        /* this little trick allows us to load properties using class loader, e.g. from a jar file */
        Properties p = new Properties();
        try {
            p.load(p.getClass().getResourceAsStream(LOGGER_PROPERTY_FILE));
        } catch (Exception e) {
            throw new Exception("Problem loading property file: "
                    + LOGGER_PROPERTY_FILE);
        }        
        PropertyConfigurator.configure(p);
        
        DNScatServer dc = new DNScatServer(argv);
        int exitCode = (dc.run()) ? (0) : (-1);
        System.exit(exitCode);
    }

}
