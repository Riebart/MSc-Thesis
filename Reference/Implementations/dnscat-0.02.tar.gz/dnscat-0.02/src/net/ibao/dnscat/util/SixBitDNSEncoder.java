/* Six bit encoder class for DNS names
 * Copyright (c) 2004 Tadeusz Pietraszek (tadek@pietraszek.org)

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: SixBitDNSEncoder.java 42 2005-08-18 09:37:47Z tadekp $
 */

package net.ibao.dnscat.util;

import org.apache.log4j.Logger;

/**
 * This class implements encoding of data into DNS names. The name uses 6 bit charset (as defined below) and longer names are
 * separated by dots (every NAMELEN characters). The class also adds encoded the frame length (the first charater).
 * @version $Id: SixBitDNSEncoder.java 42 2005-08-18 09:37:47Z tadekp $ 
 * @author Tadeusz Pietraszek (tadek@pietraszek.org).
 */
public class SixBitDNSEncoder {
    private static Logger logger = Logger.getLogger(SixBitDNSEncoder.class);
    private static final String map = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_1234567890";	/** DNS charset */
	private final int NAMELEN = 30;		/** maximum name length (after how many characters to insert dots) */
	private byte[] forwardMap;
	private byte[] reverseMap;
	
    /**
     * Construct the new DNS encoder/decoder class.
     */
    public SixBitDNSEncoder() {
        /* it is important that map is 64 bytes long */
    	assert(map.length()== 64);
    	
    	//prepare the mapping
    	forwardMap = new byte[64];
    	for(int i=0;i<64;i++)
    		forwardMap[i] = (byte) map.charAt(i);
    	
    	reverseMap = new byte[256];
    	for(int i=0;i<255;i++)
    		reverseMap[i] = 127;		//default invalid char
    	for(int i=0;i<64;i++) {
    		reverseMap[forwardMap[i]] = (byte)i; 
    	}
    }
    
    public String encode(byte[] bi) throws Exception {
        return encode(bi, bi.length);
    }
    
    /**
     * Encodes a binary buffer into a DNS name.
     * @param bi byte Data buffer
     * @param biLength Buffer length. Due to encoding used it has to be <254 (DNS can't handle more anyway)
     * @return Encoded DNS name
     * @throws Exception Something went wrong - buffer too long or too short. 
     */
    public String encode(byte[] bi, int biLength) throws Exception {
        if (logger.isDebugEnabled())			// logging
            logger.debug("encoding "+ArrayToString.get(bi, biLength));
                
    	if (biLength > 254)
    		throw new Exception("Buffer too long >254 "+bi.length);    	
    	if (biLength > bi.length)
    		throw new Exception("Length longer than the buffer size");
    	
    	
    	short[] b = new short[(biLength+1)+(3-(biLength+1)%3)];	//allocate the new array, copy length and data
    	b[0] = (short)biLength;
    	for(int i=0;i<biLength;i++) {
    		b[i+1] = (short)(((short)bi[i])&0xff);			//HACK: convert to unsigned, to prevent signed/unsigned problems!
    	}
    	StringBuffer result = new StringBuffer(b.length*4/3 + 1);	//buffer length + counter
    	int i=0;
    	while(i<b.length) {
    		short b0 = (short)(b[i]);
    		short b1 = (short)(b[i+1]);
    		short b2 = (short)(b[i+2]);
    		result.append((char)forwardMap[b0>>2]);
    		result.append((char)forwardMap[((b0&3)<<4) + (b1 >> 4)]);
    		result.append((char)forwardMap[((b1&15)<<2) + (b2 >> 6)]);
    		result.append((char)forwardMap[b2&63]);
    		i+=3;
    	}
    	
    	// now add dots
    	int cnt;
    	for(i=1, cnt = 0; i<result.length()-1;i++) {
    		cnt++;
    		if (cnt > NAMELEN) {					//dot after 30 characters
    			result.insert(i,'.');
    			cnt = 0;
    		}
    			
    	}
    	if (logger.isDebugEnabled())			// logging
    	    logger.debug("result: "+result);
    	return result.toString();
	}
	
    
    
    /**
     * Decodes a DNS name into a binary byter
     * @param si Encoded DNS name
     * @return Binary buffer
     * @throws Exception Something went wrong - wrong encoding, characters or length 
     */
    public byte[] decode(String si) throws Exception {
        if (logger.isDebugEnabled())			// logging
            logger.debug("decoding "+si);
		
        //remove dots
		StringBuffer s = new StringBuffer(si.length());
		for(int i=0; i<si.length(); i++) {
			if (si.charAt(i) != '.')
				s.append(si.charAt(i));
		}
		
		if (s.length() %4 != 0)
			throw new Exception("Invalid length exception: mod 4 != 1: "+s.length());
		
		short[] result = new short[(s.length())*3/4];
		int i=0, resultI = 0;
    	while(i<(s.length())) {
    		short b0 = reverseMap[(int)s.charAt(i)]; 
			short b1 = reverseMap[(int)s.charAt(i+1)]; 
			short b2 = reverseMap[(int)s.charAt(i+2)]; 
			short b3 = reverseMap[(int)s.charAt(i+3)]; 
    		
			if ((b0 > 63) || (b1 > 63) || (b2 > 63) || (b3 > 63))
				throw new Exception("Invalid character found: "+s.charAt(i)+" "+s.charAt(i+1)+" "+s.charAt(i+2)+" "+s.charAt(i+3));
			
			result[resultI++] = (short)((b0 << 2) + (b1 >> 4));
			result[resultI++] = (short)(((b1&15) << 4) + (b2 >> 2));
			result[resultI++] = (short)(((b2&3) << 6) + (b3));
    		i+=4;
    	}
		int ldiff = resultI - (result[0]+1);
		
		if ((ldiff < 1)||(ldiff > 3)) 
			throw new Exception("Invalid length encoded: "+result[0]+" "+resultI);
		
		byte[] resultB = new byte[result[0]];
		for(i=0;i<result[0];i++)
			resultB[i] = (byte)result[i+1];
		
		if (logger.isDebugEnabled())			// logging
		    logger.debug("result: "+ArrayToString.get(resultB));
		return resultB;
	}
}
