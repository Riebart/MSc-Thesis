/* Encoding envelope helper for DNScat
 * Copyright (c) 2004 Tadeusz Pietraszek (tadek@pietraszek.org)
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 * $Id: EncodingEnvelope.java 42 2005-08-18 09:37:47Z tadekp $
 */

package net.ibao.dnscat.util;


import org.apache.log4j.Logger;

/**
 * Helper class for DNScat
 *
 * @author Tadeusz Pietraszek (tadek@pietraszek.org)
 * @version $Id: EncodingEnvelope.java 42 2005-08-18 09:37:47Z tadekp $
 */
public class EncodingEnvelope {
    private static Logger logger = Logger.getLogger(EncodingEnvelope.class);
    private static final int MAXSEQDIFF = 50;		//maximum positive difference in packet sequences
    private int sequence;
    private byte [] idByte;
   
    public EncodingEnvelope(String id) {
        sequence = 0;
        idByte = id.getBytes();
    }
    
    public boolean isEncoded(byte[] input) {
        return isEncoded(input, input.length);
    }
    
    public boolean isEncoded(byte[] input, int inputLength) {
        if (logger.isDebugEnabled())			// logging
            logger.debug("checking "+ArrayToString.get(input, inputLength));
        
        if ( (input.length < inputLength) || (inputLength < (idByte.length+2)))
            return false;
        
        
        for(int i=0;i<idByte.length;i++)
            if (input[i] != idByte[i])
                return false;
            
        logger.debug("OK!");
        return true;
    }
    
    public int getPacketSequence(byte[] input) {
        return getPacketSequence(input, input.length);
    }
    
    public int getPacketSequence(byte[] input, int inputLength) {
        int pos = idByte.length;
        int mySequence = (((int)input[pos++]) & 0xff) + (( ((int)input[pos++]) & 0xff) << 8);
        
        logger.debug("current packet sequence: "+mySequence);
        
        return mySequence;
    }
    
    public int getSequence() {
        logger.debug("current sequence: "+sequence);
        return sequence;
    }

    public int nextSequence() {
        sequence++;
        sequence &= 0xffff;
        logger.debug("advanced sequence to: "+sequence);
        return sequence;
    }
    
    public void setSequence(int newSequence) {
        sequence = newSequence;
        logger.debug("setting sequence to: "+sequence);
    }
   
    public int getPacketSequenceDiff(byte[] input) {
        return getPacketSequenceDiff(input, input.length);
    }
    
    public int getPacketSequenceDiff(byte[] input, int inputLength) {
        int mySequence = getPacketSequence(input, inputLength);
        int diff = (mySequence  - sequence) & 0xffff;
        
        if ((diff< 0) || (diff > MAXSEQDIFF))	//if the difference is negative or too big 
            diff = diff - 65536;
        
        logger.debug("difference: "+diff);
        return diff;
    }
    
    
    
    public byte[] encode(byte[] input) throws Exception {
        return encode(input, input.length);
    }
    
    public byte[] encode(byte[] input, int inputLength) throws Exception {
        if (logger.isDebugEnabled())			// logging
        	logger.debug("encoding "+ArrayToString.get(input,inputLength));
        
        if (input.length < inputLength)
            throw new Exception("Invalid length specified");
        
        byte [] output = new byte[idByte.length + inputLength + 2];
        int pos = 0;
        
        System.arraycopy(idByte, 0, output, pos, idByte.length);
        pos += idByte.length;
        
        output[pos++] = (byte)(sequence & 0xff);
        output[pos++] = (byte)((sequence >> 8)& 0xff);
        
        System.arraycopy(input, 0, output, pos, inputLength);
        pos += inputLength;
        
        
        if (logger.isDebugEnabled())			// logging
        	logger.debug("result: "+ArrayToString.get(output));
        return output;
    }
    
    public byte[] decode(byte[] input) throws Exception {
        return decode(input, input.length);
    }
    
    public byte[] decode(byte[] input, int inputLength) throws Exception {

        if (logger.isDebugEnabled())			// logging 
            logger.debug("decoding "+ArrayToString.get(input,inputLength));
        
        if (!isEncoded(input, inputLength))
            throw new Exception("Input not encoded with EnvelopeEncoder");
        
        int mySequence = getPacketSequence(input, inputLength);
        
        if (mySequence != getSequence()) {
            logger.debug("sequence mismatch "+mySequence+" "+getSequence());
        }
        
        int pos = idByte.length + 2;	//skip ID and sequence number
        byte [] output = new byte[inputLength - idByte.length - 2];        
        System.arraycopy(input, pos, output, 0, output.length);

        if (logger.isDebugEnabled())			// logging
        	logger.debug("result: "+ArrayToString.get(output));
        
        return output;
    }
}
