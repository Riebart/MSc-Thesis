/* DNScatClient main file
 * Copyright (c) 2004 Tadeusz Pietraszek
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 * 
 * $Id: DNScatClient.java 42 2005-08-18 09:37:47Z tadekp $
 */

package net.ibao.dnscat;

import gnu.getopt.Getopt;

import java.net.SocketTimeoutException;
import java.util.Properties;

import net.ibao.dnscat.util.ArrayToString;
import net.ibao.dnscat.util.AsyncInputStream;
import net.ibao.dnscat.util.EncodingEnvelope;
import net.ibao.dnscat.util.SixBitDNSEncoder;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import org.xbill.DNS.CNAMERecord;
import org.xbill.DNS.DClass;
import org.xbill.DNS.ExtendedResolver;
import org.xbill.DNS.FindServer;
import org.xbill.DNS.Message;
import org.xbill.DNS.Name;
import org.xbill.DNS.RRset;
import org.xbill.DNS.Rcode;
import org.xbill.DNS.Record;
import org.xbill.DNS.Section;
import org.xbill.DNS.Type;

/**
 * The main class of DNScatClient.
 * @version $Id: DNScatClient.java 42 2005-08-18 09:37:47Z tadekp $
 * @author Tadeusz Pietraszek (tadek@pietraszek.org) 
 */
public class DNScatClient {
    static Logger logger = Logger.getLogger(DNScatClient.class);
    static String DNS_CAT_VERSION = "Version 0.01 (28/10/2004)";
    static String DEFAULT_PROPERTY_FILE = "/DNScatClient.properties";
    static String LOGGER_PROPERTY_FILE = "/DNScatClientLogger.properties";

    static SixBitDNSEncoder dnsEncoder = new SixBitDNSEncoder();

    private Name domainName;

    private ExtendedResolver resolver;

    private int delay1;

    private int delay2;

    private int bufferSize; //maximum length of data in one frame (both client
                            // and server)

    private AsyncInputStream ais;

    private EncodingEnvelope e;

    private EncodingEnvelope d;

    private boolean aQuery;

    private boolean ignoreTimeouts;

    /**
     * Parse parameters and construct the main object. The code is complicated and ugly, but 
     * I really couldn't find a better way of doing it.
     * 
     * @param argv Runtime parameters to parse
     * @throws Exception When something went wrong.
     * 
     */
    public DNScatClient(String[] argv) throws Exception {
        Getopt g = new Getopt("DNScatClient", argv, "?ho:d:p:t:r:L:l:Ais:S:R:");
        int c;
        String arg;

        String parDomain = null, parDNSServer = null, parDNSPort = null;
        String parDNSTimeout = null, parDNSRetries = null, parDelay1 = null, parDelay2 = null;
        String parBuffSize = null, parSendPrefix = null, parRecvPrefix = null;
        boolean parAQuery = false, parIgnoreTimeouts = false;

        System.err.println("DNScatClient - tunneling data using DNS request. " + DNS_CAT_VERSION + "\n"
                        + "Copyright (c) 2004 by Tadeusz Pietraszek (tadek@pietraszek.org).\n"
												+"  DNScat comes with ABSOLUTELY NO WARRANTY; for detailssee LICENSE file.\n"
												+"  This is free software, and you are welcome to redistribute it under certain\n"
												+"  conditions; see LICENSE in the distibution package for details.\n");
												
        try {
            Properties p = new Properties();
            try {
                p.load(getClass().getResourceAsStream(DEFAULT_PROPERTY_FILE));
            } catch (Exception e) {
                throw new Exception("Problem loading property file: "
                        + DEFAULT_PROPERTY_FILE);
            }
            if (p.isEmpty())
                throw new Exception("Property file " + DEFAULT_PROPERTY_FILE
                        + " is empty.");

            /* read default options */
            parDomain = p.getProperty("DOMAIN");
            parDNSServer = p.getProperty("DNS_SERVER");
            parDNSPort = p.getProperty("DNS_PORT");
            parDNSTimeout = p.getProperty("DNS_TIMEOUT");
            parDNSRetries = p.getProperty("DNS_RETRIES");
            parDelay1 = p.getProperty("DNS_DELAY1");
            parDelay2 = p.getProperty("DNS_DELAY2");
            parBuffSize = p.getProperty("BUFF_SIZE");
            parSendPrefix = p.getProperty("SEND_PREFIX");
            parRecvPrefix = p.getProperty("RECV_PREFIX");
            String tmp = p.getProperty("AQUERY");
            parAQuery =  (tmp != null)&& Boolean.valueOf(tmp).booleanValue();
            tmp = p.getProperty("IGNORE_TIMEOUTS");
            parIgnoreTimeouts = (tmp != null)&& Boolean.valueOf(tmp).booleanValue();

            if (parDomain != null)
                parDomain = parDomain.trim();

            while ((c = g.getopt()) != -1) {
                switch (c) {
                case 'h':
                case '?':
                    throw new Exception("Invalid Arguments");
                case 'o':
                    parDomain = g.getOptarg();
                    break;
                case 'd':
                    parDNSServer = g.getOptarg();
                    break;
                case 'p':
                    parDNSPort = g.getOptarg();
                    break;
                case 't':
                    parDNSTimeout = g.getOptarg();
                    break;
                case 'r':
                    parDNSRetries = g.getOptarg();
                    break;
                case 'L':
                    parDelay1 = g.getOptarg();
                    break;
                case 'l':
                    parDelay2 = g.getOptarg();
                    break;
                case 's':
                    parBuffSize = g.getOptarg();
                    break;
                case 'S':
                    parSendPrefix = g.getOptarg();
                    break;
                case 'R':
                    parRecvPrefix = g.getOptarg();
                    break;
                case 'A':
                    parAQuery = true;
                    break;
                case 'i':
                    parIgnoreTimeouts = true;
                    break;
                default:
                    throw new Exception("getopt() returned " + c + "\n");
                }
            }

            //now validate options
            if ((parDomain == null) || (parDomain.endsWith(".")))
                throw new Exception("Invalid domain name: " + parDomain);
            domainName = Name.fromString(parDomain + ".");
            logger.info("Using domain name: " + domainName);

            //
            String[] servers;
            if (parDNSServer != null)
                servers = new String[] { parDNSServer };
            else
                servers = FindServer.servers();
            resolver = new ExtendedResolver(servers);
            logger.info("Using DNS servers: " + ArrayToString.get(servers));

            //
            if (parDNSPort != null) {
                int port = Integer.parseInt(parDNSPort);
                resolver.setPort(port);
            }

            //
            if (parDNSTimeout != null) {
                int timeout = Integer.parseInt(parDNSTimeout);
                resolver.setTimeout(timeout);
            }

            //
            if (parDNSRetries != null) {
                int retries = Integer.parseInt(parDNSRetries);
                resolver.setRetries(c);
            }

            if (parDelay1 == null)
                throw new Exception("Delay1 not defined");
            delay1 = Integer.parseInt(parDelay1);

            if (parDelay2 == null)
                throw new Exception("Delay2 not defined");
            delay2 = Integer.parseInt(parDelay2);

            if (delay1 < delay2)
                throw new Exception("delay1 < delay2 error");
            if ((delay1 > 10000) || (delay1 < 0))
                throw new Exception("delay1 < 0 or delay1 > 10s error");
            if ((delay2 > 10000) || (delay2 < 0))
                throw new Exception("delay2 < 0 or delay2 > 10s error");

            if (parBuffSize == null)
                throw new Exception("Buffer size not defined");
            bufferSize = Integer.parseInt(parBuffSize);
            if ((bufferSize < 5) || (bufferSize > 200))
                throw new Exception("bufferSize < 5 or bufferSize > 200 error");

            //
            if (parSendPrefix == null)
                throw new Exception("Send prefix is null!");

            if (parRecvPrefix == null)
                throw new Exception("Receive prefix is null!");

            if (parSendPrefix.startsWith(parRecvPrefix)
                    || parRecvPrefix.startsWith(parSendPrefix))
                throw new Exception(
                        "Send and receive prefix should not be substrings of each other.");

            e = new EncodingEnvelope(parSendPrefix);
            d = new EncodingEnvelope(parRecvPrefix);

            aQuery = parAQuery;
            ignoreTimeouts = parIgnoreTimeouts;
        } catch (Exception e) {
            System.err.println("\nDNScatClient [-o <domain name>][-d <server>][-p <port>][-t <dns timeout>]\n"+
                            "             [-r <retires>][-L <send delay>][-l <send delay>][-A][-i]\n" +
                            "             [-s <buffer size>][-S <prefix>][-R <prefix>]\n\n" +
                            "	-h, -? - print this screen\n" +
                            "	-o <domain name> - domain name that is delegated to the server ("+parDomain+")\n" +
                            "	-d <dns server> - DNS server to send (default - use system settings)\n" +
                            "	-p <dns port> - DNS port to use (" + parDNSPort + ")\n" +
                            "	-t <dns timeout> - DNS server timeout (" + parDNSTimeout + " sec)\n" +
                            "	-r <retires> - DNS server retries (" + parDNSRetries + ")\n" +
                            "	-L <send delay> - null query delay (" + parDelay1 + " ms)\n" +
                            "	-l <send delay> - complete query delay (" + parDelay2 + " ms)\n" +
                            "	-A - use A queries instead of CNAME (" + parAQuery + ")\n" +
                            "	-i - ignore timeouts (" + parIgnoreTimeouts + ")\n" +
                            "	-s <buffer size> - buffer size (" + parBuffSize + ")\n" +
                            "	-S <prefix> - send prefix (" + parSendPrefix + ")\n" + 
                            "	-R <prefix> - recieve preifx (" + parRecvPrefix + ")\n" + "\n");
            throw e;
        }
    }

    /***************************************************************************
     * Transmit the string to the DNS server and return the reply
     * 
     * @param send
     *            String to be sent (DNS encoded)
     * @return returned string (DNS encoded)
     * @throws Exception
     *             Something went wrong
     */
    public String transmitRequest(String send) throws Exception {

        logger.debug("sending string: " + send);

        Name name = Name.fromString(send, domainName);
        Record question = Record.newRecord(name, (aQuery) ? Type.A : Type.CNAME, DClass.IN);
        Message query = Message.newQuery(question);

        Message response = null;

        response = resolver.send(query);
        int rcode = response.getHeader().getRcode();

        if (rcode != Rcode.NOERROR) {
            // The server we contacted is broken or otherwise unhelpful.
            // Press on.
            throw new Exception("Lookup ERROR " + Rcode.string(rcode));
        }

        if (!query.getQuestion().equals(response.getQuestion())) {
            // The answer doesn't match the question. That's not good.
            throw new Exception("Response doesn't match query");
        }

        RRset[] rrSet = response.getSectionRRsets(Section.ANSWER);
        CNAMERecord responseRecord = null;
        for (int i = 0; i < rrSet.length; i++) {
            Record rr = rrSet[i].first();
            if (rr instanceof CNAMERecord) {
                responseRecord = (CNAMERecord) rr;
                break;
            }
        }

        if (responseRecord == null) {
            throw new Exception("No CNAME Record in Response: " + response);
        }

        //we have the response record - extract info from CNAME
        Name responseAlias = responseRecord.getAlias();

        if (!responseAlias.subdomain(domainName)) {
            throw new Exception("Alias in CNAME does not have a correct domain");
        }
        Name responseAliasRelative = responseAlias.relativize(domainName);

        logger.debug("received: " + responseAliasRelative);
        return responseAliasRelative.toString();
    }

    public boolean run() {
        try {

            byte[] rbuff = new byte[bufferSize];
            byte[] wbuff;
            boolean skipdelay = false;

            ais = new AsyncInputStream(bufferSize);

            while (true) {
                if ((ais.available() == 0) && (!skipdelay)) {
                    try {
                        Thread.sleep(delay1); //long delay
                    } catch (InterruptedException ie) {
                    }
                } else if (skipdelay) {
                    try {
                        Thread.sleep(delay2); //short delay
                    } catch (InterruptedException ie) {
                    }
                }
                skipdelay = false;

                int rbuffRead = (ais.available() != 0) ? ais.read(rbuff) : 0;

                if ((rbuffRead == 0) && (ais.isEOF())) {
                    logger.info("end of input stream - terminating");
                    break;
                }

                logger.debug("sending " + rbuffRead + " bytes");

                try {
                    byte [] p = dnsEncoder.decode((transmitRequest(dnsEncoder.encode(e.encode(rbuff, rbuffRead)))));
                    logger.info("packet "+d.getPacketSequence(p));
                    wbuff = d.decode(p);
                
                }
                catch (SocketTimeoutException ste) {
                    if (ignoreTimeouts) {
                        logger.info("Timeout ignored",ste);
                        e.nextSequence();
                        continue;			//ignore timeout
                    }
                    else throw ste;
                }
                e.nextSequence();

                logger.debug("received " + wbuff.length + " bytes");

                if (wbuff.length == bufferSize)
                    skipdelay = true;

                System.out.write(wbuff);
            }

        } catch (Exception e) {
            logger.error("Exception has occurred. System terminating", e);
            return false;
        } finally {
            ais.terminate();
        }
        return true;
    }

    public static void main(String[] argv) throws Exception {
        /* this little trick allows us to load properties using class loader, e.g. from a jar file */
        Properties p = new Properties();
        try {
            p.load(p.getClass().getResourceAsStream(LOGGER_PROPERTY_FILE));
        } catch (Exception e) {
            throw new Exception("Problem loading property file: "
                    + LOGGER_PROPERTY_FILE);
        }
        PropertyConfigurator.configure(p);
        
        
        DNScatClient dc = new DNScatClient(argv);
        int exitCode = (dc.run()) ? (0) : (-1);
        System.exit(exitCode);
    }

}
